const test=require('node:test'),assert=require('node:assert/strict'),{openPanel}=require('../extension/panel-window.js');
function mock(existing=[],window={type:'popup',state:'normal'}){
  const calls=[];return {calls,runtime:{getURL:name=>'chrome-extension://local/'+name},tabs:{query:async()=>existing,update:async(...args)=>calls.push(['tab',...args])},windows:{get:async()=>window,update:async(...args)=>calls.push(['focus',...args]),create:async value=>calls.push(['create',value])}};
}
test('重复点击只创建一个 580×800 控制窗口',async()=>{
  const api=mock();await Promise.all([openPanel(api),openPanel(api),openPanel(api)]);
  assert.equal(api.calls.length,1);assert.deepEqual(api.calls[0],['create',{type:'popup',width:580,height:800,focused:true,url:'chrome-extension://local/popup.html'}]);
});
test('再次打开复用原窗口并从最小化恢复',async()=>{
  const api=mock([{id:8,windowId:7,url:'chrome-extension://local/popup.html'}],{type:'popup',state:'minimized'});await openPanel(api);
  assert.deepEqual(api.calls,[['tab',8,{active:true}],['focus',7,{focused:true,state:'normal'}]]);
});
test('普通标签页中的控制台移入小窗口；关闭后可重新打开',async()=>{
  const api=mock([{id:8,windowId:7,url:'chrome-extension://local/popup.html'}],{type:'normal'});await openPanel(api);
  assert.equal(api.calls[0][1].tabId,8);assert.equal(api.calls[0][1].url,undefined);
  const fresh=mock();await openPanel(fresh);assert.equal(fresh.calls[0][0],'create');
});
test('打开窗口失败后允许再次尝试',async()=>{
  const api=mock();api.windows.create=async()=>{throw new Error('窗口已关闭');};await assert.rejects(openPanel(api),/窗口已关闭/);
  const retry=mock();await openPanel(retry);assert.equal(retry.calls.length,1);
});
test('可从扩展页面上下文找到窗口，无需读取其他标签页信息',async()=>{
  const api=mock();api.runtime.getContexts=async filter=>{assert.deepEqual(filter.documentUrls,['chrome-extension://local/popup.html']);return [{tabId:8,windowId:7}];};api.tabs.query=async()=>{throw new Error('不应扫描标签页');};
  await openPanel(api);assert.equal(api.calls[0][1],8);assert.equal(api.calls[1][1],7);
});
