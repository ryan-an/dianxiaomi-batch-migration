// Local UI fixture only. No tab navigation or remote requests are implemented.
const mockData={},fixtureState=new URL(location.href).searchParams.get('state')||'ready';
let fixtureJob=null,fixtureInitialized=false;
const initMock=(async()=>{
  if(fixtureState==='idle')return;
  const bytes=new Uint8Array(await(await fetch('/迁移数据.xls')).arrayBuffer());let b='';
  for(let i=0;i<bytes.length;i+=8192)b+=String.fromCharCode(...bytes.subarray(i,i+8192));
  mockData.dxmFile={name:'迁移数据.xls',size:bytes.length,base64:btoa(b)};
  mockData.dxmUIPrefs={startIndex:2,limit:1,scope:'one'};
})();
async function initializeFixture(){
  await initMock;if(fixtureInitialized)return;fixtureInitialized=true;
  if(!['running','done','review','stopped','error'].includes(fixtureState))return;
  const rows=DXMCore.parseWorkbook(XLSX.read(mockData.dxmFile.base64,{type:'base64'}),XLSX,{mergeSplit:true}).rows;
  rows.forEach((r,i)=>{r.status=i===1?'待执行':'未执行';});
  Object.assign(rows[1],{title:'10 PCS Gold S Hooks, Brass S Hooks for Hanging',collectorId:'184527809328870833',productId:'184807703383437685'});
  fixtureJob={id:'local-ui-demo',rows,state:fixtureState==='done'?'done':fixtureState,tabId:101,options:{startIndex:2,limit:1},step:'正在填写第 2 条产品的信息',logs:[{time:'14:30:00',message:'开始处理第 2 条，共 1 条产品。'},{time:'14:30:02',message:'已确认目标店铺：万万欣DE / 英国。'},{time:'14:30:05',message:'采集完成，已对应来源链接与产品标题。'},{time:'14:30:08',message:'已认领，并移入待发布。'},{time:'14:30:12',message:'正在填写产品信息，配送方式设为 FBA。'}]};
  if(fixtureState==='done'){rows[1].status='已提交待确认';fixtureJob.logs.push({time:'14:30:20',message:'保存并发布已提交，等待平台确认。'});}
  if(fixtureState==='stopped')rows[1].status='已停止';
  if(fixtureState==='review'||fixtureState==='error'){rows[1].status=fixtureState==='review'?'待人工核对':'失败';rows[1].error='示例：平台未返回明确结果，请核对当前产品。';fixtureJob.error=rows[1].error;}
}
window.chrome={
  storage:{local:{get:async keys=>{await initMock;installMockExport();return Object.fromEntries((Array.isArray(keys)?keys:[keys]).map(k=>[k,mockData[k]]));},set:async value=>Object.assign(mockData,value)}},
  tabs:{query:async()=>fixtureState==='notabs'?[]:[{id:101,windowId:1,active:true,url:'https://www.dianxiaomi.com/web/amazon/pageList/draft',title:'店小秘 - 采集箱'},{id:102,windowId:1,active:false,url:'https://www.dianxiaomi.com/web/productCrawl/dataAcquisition',title:'店小秘 - 数据采集'}]},
  runtime:{sendMessage:async message=>{
    await initializeFixture();
    if(message.kind==='DXM_STATUS')return {ok:true,job:fixtureJob};
    if(message.kind==='DXM_START'){
      if(fixtureState==='start-error')return {ok:false,error:'本地示例：选择的店小秘页面已关闭，请刷新页面列表。'};
      const rows=structuredClone(message.rows);rows.forEach((r,i)=>{if(!r.error)r.status=i>=message.options.startIndex-1&&i<message.options.startIndex-1+message.options.limit?'待执行':'未执行';});
      fixtureJob={id:'local-start-demo',rows,options:message.options,tabId:message.tabId,state:'running',step:'本地演示：正在准备采集',logs:[{time:'14:32:00',message:'这是本地 UI 模拟，没有连接店小秘。'}]};return {ok:true};
    }
    if(message.kind==='DXM_STOP'){
      if(fixtureJob){fixtureJob.stop=true;setTimeout(()=>{fixtureJob.state='stopped';fixtureJob.rows.forEach(r=>{if(r.status==='待执行')r.status='已停止';});fixtureJob.logs.push({time:'14:32:05',message:'已停止，本轮结果已保留。'});},1800);}return {ok:true};
    }
    return {ok:false,error:'本地预览不支持此操作'};
  }}
};
function installMockExport(){
  if(document.getElementById('mockExportCheck'))return;
  const check=document.body.appendChild(document.createElement('output'));check.id='mockExportCheck';check.hidden=true;check.style.cssText='display:block;margin:12px;padding:12px;background:#edf3ff;color:#245bd6;font:12px system-ui';check.textContent='本地导出检查已就绪。';
  XLSX.writeFile=(book,name)=>{
    check.hidden=false;
    const bytes=XLSX.write(book,{type:'array',bookType:'xlsx'}),read=XLSX.read(bytes,{type:'array'}),sheet=read.Sheets[read.SheetNames[0]],rows=XLSX.utils.sheet_to_json(sheet,{header:1});
    const idCells=['J3','K3'].map(key=>sheet[key]);
    const exact=idCells.every(cell=>cell?.t==='s'&&/^\d{18}$/.test(cell.v));
    check.textContent=`本地导出检查：${name}；${rows.length-1} 条产品；${bytes.byteLength} 字节；采集 ID 与产品 ID ${exact?'保持完整文本':'无演示 ID'}。此预览仅验证 XLSX 内容，不启动浏览器下载。`;
  };
}
