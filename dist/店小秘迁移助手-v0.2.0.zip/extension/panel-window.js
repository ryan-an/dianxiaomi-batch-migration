(function(root){
  'use strict';let opening;
  async function openPanel(api=chrome){
    if(!opening)opening=(async()=>{
      const url=api.runtime.getURL('popup.html');
      const contexts=api.runtime.getContexts?await api.runtime.getContexts({contextTypes:['TAB'],documentUrls:[url]}):[];
      const context=contexts.find(c=>c.tabId>=0);
      const existing=context?{id:context.tabId,windowId:context.windowId}:(await api.tabs.query({})).find(t=>t.url===url);
      if(existing){
        const win=await api.windows.get(existing.windowId);
        if(win.type==='popup'){await api.tabs.update(existing.id,{active:true});await api.windows.update(existing.windowId,{focused:true,...(win.state==='minimized'?{state:'normal'}:{})});return;}
        await api.windows.create({type:'popup',width:580,height:800,focused:true,tabId:existing.id});return;
      }
      await api.windows.create({type:'popup',width:580,height:800,focused:true,url});
    })().finally(()=>{opening=null;});
    return opening;
  }
  root.DXMPanelWindow={openPanel};if(typeof module!=='undefined')module.exports={openPanel};
})(globalThis);
