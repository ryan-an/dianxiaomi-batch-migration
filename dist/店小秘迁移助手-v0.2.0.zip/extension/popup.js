(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  let book=null,parsed=null,fileInfo=null,job=null,tabs=[],reading=false,starting=false,refreshing=false,localError=null;
  let prefs={startIndex:1,limit:1,scope:'one',mergeSplit:true,modelNameFromNumber:true,shopAliases:{...DXMCore.alias},tabId:null};
  let logSignature='',recordSignature='',lastOpenedJob='',lastConfigJob='',prefsQueue=Promise.resolve();
  const element=(tag,text,className)=>{const el=document.createElement(tag);if(text!=null)el.textContent=text;if(className)el.className=className;return el;};
  const busy=()=>job?.state==='running';
  function savePrefs(){
    const snapshot=structuredClone(prefs);
    prefsQueue=prefsQueue.catch(()=>{}).then(()=>chrome.storage.local.set({dxmUIPrefs:snapshot}));
  }
  function showError(title,error){localError={title,text:error.message||String(error)};render();}
  function currentRange(){return parsed?DXMUI.range(parsed.rows,$('startIndex').value,$('limit').value):null;}
  function readRange(){
    prefs.startIndex=$('startIndex').value;prefs.limit=$('limit').value;
    if(prefs.scope==='all'&&parsed){prefs.limit=Math.max(1,parsed.rows.length-Number(prefs.startIndex)+1);$('limit').value=prefs.limit;}
    savePrefs();render();
  }
  function parseFile(rebuildMappings=true){
    try{
      parsed=DXMCore.parseWorkbook(book,XLSX,{mergeSplit:$('mergeSplit').checked,shopAliases:prefs.shopAliases});
      localError=null;if(prefs.scope==='all'){$('limit').value=Math.max(1,parsed.rows.length-Number($('startIndex').value)+1);prefs.limit=$('limit').value;}
      if(rebuildMappings)renderMappings();
    }catch(error){parsed=null;localError={title:'表格暂时无法解析',text:error.message};}
    recordSignature='';render();
  }
  function renderMappings(){
    const body=$('mappings');body.replaceChildren();
    const groups=new Map();for(const row of parsed?.rows||[])if(row.shop&&row.site)groups.set(`${row.shop}|${row.site}`,row);
    for(const [key,row] of groups){
      const tr=element('tr'),source=element('td'),target=element('td');
      source.append(element('span',row.shop,'mapping-source'),element('span',row.site,'mapping-site'));
      const input=element('input');input.type='text';input.value=prefs.shopAliases[key]||row.shop;
      input.setAttribute('aria-label',`${row.shop} / ${row.site}的实际店铺`);input.autocomplete='off';
      input.addEventListener('change',()=>{
        if(!input.value.trim()){input.value=prefs.shopAliases[key]||row.shop;return;}
        prefs.shopAliases[key]=input.value.trim();savePrefs();parseFile(false);
      });target.append(input);tr.append(source,target);body.append(tr);
    }
    $('mappingBlock').hidden=!groups.size;
  }
  async function importFile(file){
    if(!file||busy()||reading||starting)return;
    if(!/\.xlsx?$/i.test(file.name)){showError('请选择 Excel 文件',new Error('支持 .xls 和 .xlsx 格式。'));return;}
    if(file.size>5*1024*1024){showError('表格文件过大',new Error('请使用 5 MB 以内的表格。'));return;}
    reading=true;localError=null;render();
    try{
      const bytes=new Uint8Array(await file.arrayBuffer());
      const nextBook=XLSX.read(bytes,{type:'array'});
      let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
      const nextFile={name:file.name,size:file.size,base64:btoa(binary)};
      book=nextBook;fileInfo=nextFile;parseFile();$('settingsDetails').open=true;
      await chrome.storage.local.set({dxmFile:nextFile});
    }catch(error){showError('导入未完成',error);}finally{reading=false;$('file').value='';render();}
  }
  function validTab(tab){try{const url=new URL(tab.url);return url.origin==='https://www.dianxiaomi.com'&&/^\/web\/(amazon\/|productCrawl\/)/.test(url.pathname);}catch{return false;}}
  async function refreshTabs(){
    $('refreshTabs').disabled=true;
    try{
      tabs=(await chrome.tabs.query({url:['https://www.dianxiaomi.com/web/*']})).filter(validTab);
      const previous=Number($('targetTab').value)||prefs.tabId;
      const target=(busy()?tabs.find(t=>t.id===job.tabId):tabs.find(t=>t.id===previous))||tabs.find(t=>t.active)||tabs[0];
      $('targetTab').replaceChildren();
      if(!tabs.length){const option=element('option','未找到店小秘页面');option.value='';$('targetTab').append(option);}
      const counts=new Map();for(const tab of tabs){const label=DXMUI.tabLabel(tab);counts.set(label,(counts.get(label)||0)+1);}
      const seen=new Map();
      for(const tab of tabs){const base=DXMUI.tabLabel(tab),n=(seen.get(base)||0)+1;seen.set(base,n);const option=element('option',counts.get(base)>1?`${base} (${n})`:base);option.value=tab.id;$('targetTab').append(option);}
      if(target){$('targetTab').value=target.id;prefs.tabId=target.id;savePrefs();}
    }catch(error){tabs=[];showError('无法读取店小秘页面',error);}finally{$('refreshTabs').disabled=false;render();}
  }
  function renderRecords(){
    const rows=job?.rows||parsed?.rows||[];
    const signature=JSON.stringify([job?.id,rows.map(r=>[r.status,r.title,r.error,r.step,r.source]),$('startIndex').value,$('limit').value]);
    if(signature===recordSignature)return;recordSignature=signature;
    $('recordsDetails').hidden=!rows.length;$('recordsLabel').textContent=job?`查看本轮产品明细（${rows.length} 条）`:`预览表格产品（${rows.length} 条）`;
    const body=$('records');body.replaceChildren();
    const range=currentRange();
    for(let index=0;index<Math.min(rows.length,200);index++){
      const row=rows[index],tr=element('tr'),product=element('td'),state=element('td');
      product.append(element('span',row.title||row.data?.['标题']||row.data?.['Parent SKU']||'等待采集标题','record-product'));
      const source=element('span',row.source,'record-source');source.title=row.source||'';product.append(source);
      let status=row.status;if(!job&&!row.error)status=range?.rows.includes(row)?'本次执行':'未选中';
      const badge=element('span',status,'state-tag');badge.dataset.tone=!job&&status==='未选中'?'idle':DXMUI.statusTone(status);state.append(badge);
      if(row.error){const error=element('span',row.error,'record-source');state.append(error);}
      tr.append(element('td',String(index+1)),product,state);body.append(tr);
    }
    $('recordsHint').textContent=[job?'结果来自最近一次执行；下载结果可查看来源与完整步骤。':'选中范围会标记为“本次执行”，开始前可在这里核对。',rows.length>200?'窗口仅展示前 200 条，下载结果包含全部产品。':''].filter(Boolean).join(' ');
  }
  function renderLogs(){
    const logs=job?.logs||[],signature=JSON.stringify(logs);if(signature===logSignature)return;logSignature=signature;
    const box=$('logs'),follow=box.scrollHeight-box.clientHeight-box.scrollTop<35;
    const previousTop=box.scrollTop;box.replaceChildren();
    if(!logs.length)box.append(element('p','开始后会在这里记录每个步骤。','log-empty'));
    for(const entry of logs){const line=element('p',null,'log-entry'),time=element('time',(entry.time||'').match(/\d{1,2}:\d{2}:\d{2}/)?.[0]||entry.time||'');time.title=entry.time||'';line.append(time,element('span',entry.message||''));box.append(line);}
    $('logCount').textContent=logs.length?`${logs.length} 条记录`:'暂无记录';
    if(follow)box.scrollTop=box.scrollHeight;else box.scrollTop=previousTop;
    $('latestLog').hidden=follow||!logs.length;
    if(job?.state==='running'&&lastOpenedJob!==job.id){$('logDetails').open=true;lastOpenedJob=job.id;box.scrollTop=box.scrollHeight;}
  }
  function render(){
    const summary=DXMUI.summary(job),locked=summary.busy||reading||starting,range=currentRange();
    $('settingsToggle').hidden=!job;
    $('settingsSummary').textContent=job?`第 ${job.options?.startIndex||1} 条起 · 本轮 ${summary.total} 条`:'';
    if(job&&lastConfigJob!==job.id){$('settingsDetails').open=false;lastConfigJob=job.id;}
    $('settings').disabled=locked;
    $('start').disabled=locked||!range||!!range.error||!range.valid||!tabs.some(t=>t.id===Number($('targetTab').value));
    $('startLabel').textContent=starting?'正在开始…':summary.busy?'执行中':range&&!range.error?`开始执行 ${range.count} 条`:'开始执行';
    $('stop').disabled=!summary.busy||summary.stopping;$('stopLabel').textContent=summary.stopping?'正在停止…':'停止';
    $('download').disabled=!job?.rows?.length;
    $('status').dataset.tone=summary.tone;
    $('status').textContent=reading?'正在读取表格…':starting?'正在准备本轮迁移…':job?summary.label:parsed?'已就绪，等待开始':'准备就绪';
    $('controlsHint').textContent=summary.busy?(summary.stopping?'停止请求已发送，完成当前步骤后保留结果。':'执行中已锁定店小秘页面，可关闭此窗口，稍后再打开。'):job?'下载本轮结果；展开设置可调整下一轮的店铺与范围。':parsed?'核对下方店铺与范围，点击开始后按顺序执行。':'先导入迁移表格，默认每次只执行 1 条。';
    $('filename').textContent=fileInfo?.name||'选择你的迁移表格';$('chooseFile').textContent=fileInfo?'更换文件':'选择文件';
    $('fileMeta').textContent=fileInfo?`${book?.SheetNames.length||0} 张工作表 · ${Math.max(1,Math.round((fileInfo.size||fileInfo.base64.length*.75)/1024))} KB · 已保存在本机`:'点击上传，也可以把文件拖到这里';
    $('fileBadge').textContent=parsed?'已解析':'支持 XLS / XLSX';
    $('fileHint').hidden=!parsed?.warnings.length;$('fileHint').textContent=parsed?.warnings.join('；')||'';
    $('importSummary').hidden=!parsed;$('totalRows').textContent=parsed?.rows.length||0;
    const invalid=parsed?.rows.filter(r=>r.error).length||0;
    $('validRows').textContent=(parsed?.rows.length||0)-invalid;$('invalidRows').textContent=invalid;$('invalidSummary').hidden=!invalid;
    if(!parsed)$('mappingBlock').hidden=true;
    $('rangeHint').textContent=!parsed?'先导入表格，再选择执行范围。':range.error||`本次处理第 ${range.start}${range.end>range.start?`–${range.end}`:''} 条，共 ${range.count} 条产品${range.valid<range.count?`（${range.count-range.valid} 条数据问题会记录在结果中）`:''}。`;
    $('rangeHint').classList.toggle('error',!!range?.error);
    $('oneItem').setAttribute('aria-pressed',String(prefs.scope==='one'));$('allItems').setAttribute('aria-pressed',String(prefs.scope==='all'));
    $('targetHint').hidden=!!tabs.length;$('targetHint').textContent='请在安装此插件的浏览器中打开并登录店小秘，再点击右侧刷新。';
    const error=localError||(job?.error?{title:'本轮需要处理',text:job.error}:null);
    $('message').hidden=!error;$('messageTitle').textContent=error?.title||'';$('messageText').textContent=error?.text||'';
    $('execution').hidden=!job;$('progressText').textContent=`已处理 ${summary.processed} / ${summary.total} 条`;
    $('progressFill').style.width=`${summary.percent}%`;$('progressBar').setAttribute('aria-valuenow',summary.percent);
    $('successCount').textContent=summary.success;$('pendingCount').textContent=summary.pending;$('failedCount').textContent=summary.failed+summary.review;
    $('executionNote').textContent=summary.skipped?`${summary.skipped} 条已有采集记录，已跳过。`:'“已上线”以店小秘在线列表核对为准；待平台确认的产品会单独记录。';
    renderRecords();renderLogs();
  }
  async function refresh(){
    if(refreshing)return;refreshing=true;
    try{const result=await chrome.runtime.sendMessage({kind:'DXM_STATUS'});if(!result?.ok)throw new Error(result?.error||'无法获取执行状态');job=result.job||null;render();}
    catch(error){showError('无法获取执行状态',error);}finally{refreshing=false;}
  }
  $('chooseFile').onclick=()=>$('file').click();$('file').onchange=()=>importFile($('file').files[0]);
  $('dropzone').addEventListener('dragover',event=>{event.preventDefault();if(!busy()&&!reading&&!starting)$('dropzone').classList.add('dragging');});
  $('dropzone').addEventListener('dragleave',()=>$('dropzone').classList.remove('dragging'));
  $('dropzone').addEventListener('drop',event=>{event.preventDefault();$('dropzone').classList.remove('dragging');importFile(event.dataTransfer.files[0]);});
  $('startIndex').oninput=readRange;$('limit').oninput=()=>{prefs.scope='custom';readRange();};
  $('oneItem').onclick=()=>{prefs.scope='one';$('limit').value=1;readRange();};
  $('allItems').onclick=()=>{prefs.scope='all';readRange();};
  $('targetTab').onchange=()=>{prefs.tabId=Number($('targetTab').value);savePrefs();render();};$('refreshTabs').onclick=refreshTabs;
  $('mergeSplit').onchange=()=>{prefs.mergeSplit=$('mergeSplit').checked;savePrefs();if(book)parseFile();};
  $('modelNameFromNumber').onchange=()=>{prefs.modelNameFromNumber=$('modelNameFromNumber').checked;savePrefs();};
  $('start').onclick=async()=>{
    const range=currentRange();if(busy()||starting||!range||range.error||!range.valid)return;
    starting=true;localError=null;render();
    try{
      const result=await chrome.runtime.sendMessage({kind:'DXM_START',rows:parsed.rows,options:{startIndex:range.start,limit:range.count,modelNameFromNumber:$('modelNameFromNumber').checked},tabId:Number($('targetTab').value)});
      if(!result?.ok)throw new Error(result?.error||'任务未启动');await refresh();
    }catch(error){showError('未能开始迁移',error);}finally{starting=false;render();}
  };
  $('stop').onclick=async()=>{
    $('stop').disabled=true;
    try{const result=await chrome.runtime.sendMessage({kind:'DXM_STOP'});if(!result?.ok)throw new Error(result?.error||'停止请求未发送');await refresh();}
    catch(error){showError('未能停止',error);}
  };
  $('download').onclick=()=>{
    if(!job?.rows?.length)return;
    const table=DXMCore.resultTable(job.rows),sheet=XLSX.utils.aoa_to_sheet(table);
    sheet['!cols']=[{wch:15},{wch:48},{wch:60},{wch:20},{wch:10},{wch:22},{wch:55},{wch:25},{wch:20},{wch:25},{wch:25},{wch:28},{wch:48},{wch:80}];
    const output=XLSX.utils.book_new();XLSX.utils.book_append_sheet(output,sheet,'迁移结果');
    XLSX.writeFile(output,`迁移结果_${new Date().toISOString().slice(0,10)}.xlsx`);
  };
  $('latestLog').onclick=()=>{$('logs').scrollTop=$('logs').scrollHeight;$('latestLog').hidden=true;};
  $('logs').onscroll=()=>{$('latestLog').hidden=$('logs').scrollHeight-$('logs').clientHeight-$('logs').scrollTop<35;};
  async function init(){
    try{
      const stored=await chrome.storage.local.get(['dxmFile','dxmUIPrefs']);
      prefs={...prefs,...stored.dxmUIPrefs,shopAliases:{...DXMCore.alias,...stored.dxmUIPrefs?.shopAliases}};
      $('startIndex').value=prefs.startIndex;$('limit').value=prefs.limit;$('mergeSplit').checked=prefs.mergeSplit;$('modelNameFromNumber').checked=prefs.modelNameFromNumber;
      if(stored.dxmFile){fileInfo=stored.dxmFile;book=XLSX.read(fileInfo.base64,{type:'base64'});parseFile();}
    }catch(error){showError('上次的表格未能恢复，请重新上传',error);}
    await refresh();await refreshTabs();render();setInterval(refresh,1500);
  }
  init();
})();
