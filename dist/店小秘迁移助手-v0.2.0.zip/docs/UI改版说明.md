# v0.2 界面与交互

参考：[auto-invoice-grist](https://github.com/ryan-an/auto-invoice-grist)，重点参考其中 `自动化开票/extension/panel.html`、`panel.css`、`workflow-panel.mjs`、`panel-window.mjs` 的控制窗口、操作栏和折叠区域。以本项目的迁移流程重新实现，没有执行参考仓库的代码。

## 使用路径

点击插件图标 → 选择或拖入表格 → 查看产品数量与目标店铺 → 选择起始产品和执行数量 → 选择店小秘标签页 → 开始执行 → 查看进度和日志 → 下载结果。

控制窗口默认 580×800，可调整大小。再次点击插件图标会聚焦原窗口。执行开始后设置自动折叠，保留进度与日志；用户仍可展开查看设置，但执行结束前不能修改。更多规则、产品明细和历史日志按需展开。

表格、店铺映射、执行范围和填写选项保存在本机。页面输入在执行期间锁定，停止后先等待当前步骤结束，再开放新任务。没有加入“断点继续”按钮，后台仍按原有核对机制处理提交不确定的产品。

## 本地验证

此次未操作店小秘的任何真实产品，原先的 1 条已上线、9 条未执行结果保持不变。

- 数据、工作流、范围与状态、独立窗口复用共 23 项 Node 测试通过。
- 内置浏览器中检查真实 UI 文件：已导入、执行中、停止中、已停止、待平台确认、未打开店小秘、范围越界和产品预览。
- 320、420、580 宽度的页面没有横向溢出，按钮、输入和下拉框没有越界。
- 本地模拟开始后设置禁用；停止请求先显示“正在停止”，结束后恢复可操作。
- 内置浏览器以真实坐标点击本地普通按钮：执行中计数保持 0，停止后增加为 1；新版浮层没有破坏页面输入锁定。
- 本地导出检查使用生产 UI 的导出处理器及打包的 SheetJS 生成 XLSX，再读取核对行数与长 ID 文本类型。浏览器原生下载事件等待曾超时，未将该项视为下载成功；本版未安装扩展进行下载链路或真实批次测试。
- 原有 DOM 证据与数据流程不因本次 UI 改版重新消耗产品。

![上传与设置，本地模拟](evidence/ui-v0.2-ready.png)

![运行状态，本地模拟](evidence/ui-v0.2-running.png)

## 扩展页面

移除 `action.default_popup`，由工具栏点击打开独立窗口；窗口关闭不会停止后台任务。由于控制台现在单独占用窗口，明确选择店小秘标签页，避免误把控制台所在窗口当成工作页面。优先通过扩展页面上下文复用窗口，兼容回退为自身页面标签检索。未增加权限。

相关官方 API：[Chrome Action](https://developer.chrome.com/docs/extensions/reference/api/action)、[Chrome Windows](https://developer.chrome.com/docs/extensions/reference/api/windows)、[Chrome Runtime](https://developer.chrome.com/docs/extensions/reference/api/runtime#method-getContexts)。
