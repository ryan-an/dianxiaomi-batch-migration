const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),X=require('../extension/vendor/xlsx.full.min.js');
const m=JSON.parse(fs.readFileSync('extension/manifest.json','utf8'));assert.equal(m.manifest_version,3);
for(const file of [m.background.service_worker,m.action.default_popup,...m.content_scripts.flatMap(x=>x.js)])assert.ok(fs.existsSync(path.join('extension',file)),file);
for(const file of fs.readdirSync('extension').filter(f=>f.endsWith('.js')))new vm.Script(fs.readFileSync(path.join('extension',file),'utf8'),{filename:file});
const w=X.read(fs.readFileSync('outputs/单条实测结果.xlsx'));
const s=w.Sheets[w.SheetNames[0]];assert.equal(s.J6.v,'184527809328870833');assert.equal(s.J6.t,'s');assert.equal(s.K6.v,'184807703383437685');assert.equal(s.K6.t,'s');
const rows=JSON.parse(fs.readFileSync('outputs/单条实测结果.json','utf8'));assert.equal(rows.filter(x=>x.status==='已上线').length,1);assert.equal(rows.filter(x=>x.status==='未执行').length,9);
for(const name of fs.readdirSync('docs/evidence').filter(f=>/\.(html|json)$/.test(f)))assert.ok(!fs.readFileSync(path.join('docs/evidence',name),'utf8').includes('[Truncated]'),`DOM截断: ${name}`);
console.log('包引用与全部扩展脚本语法通过；结果为1条已上线、9条未执行，18位ID保持文本；DOM片段无截断。');
