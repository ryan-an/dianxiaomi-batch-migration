const mockData={};
const initMock=(async()=>{const bytes=new Uint8Array(await(await fetch('/迁移数据.xls')).arrayBuffer());let b='';for(let i=0;i<bytes.length;i+=8192)b+=String.fromCharCode(...bytes.subarray(i,i+8192));mockData.dxmFile={name:'迁移数据.xls',base64:btoa(b)};})();
window.chrome={storage:{local:{get:async key=>{await initMock;return {[key]:mockData[key]};},set:async value=>Object.assign(mockData,value)}},tabs:{query:async()=>[{id:1}]},runtime:{sendMessage:async message=>message.kind==='DXM_STATUS'?{ok:true,job:null}:{ok:false,error:'本地界面预览不会执行真实任务'}}};
