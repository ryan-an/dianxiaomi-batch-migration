'use strict';
const $=s=>document.querySelector(s);let book=null,parsed=null,lastJob=null;
const request=m=>chrome.runtime.sendMessage(m);
function mappings(){const out={};for(const line of $('#aliases').value.split(/\r?\n/).filter(x=>x.trim())){const at=line.indexOf('=');if(at<1)throw new Error('店铺映射格式应为 原店铺|站点=实际店铺');out[line.slice(0,at).trim()]=line.slice(at+1).trim();}return out;}
function parse(){if(!book)throw new Error('请先选择表格');parsed=DXMCore.parseWorkbook(book,XLSX,{mergeSplit:$('#mergeSplit').checked,shopAliases:mappings()});const good=parsed.rows.filter(r=>!r.error);$('#preview').textContent=`${parsed.rows.length} 条产品，${good.length} 条数据有效。目标：${parsed.groups.join('、')}。${parsed.warnings.join('；')}`;return parsed;}
function download(){
  if(!lastJob)return;
  const data=DXMCore.resultTable(lastJob.rows),book=XLSX.utils.book_new(),sheet=XLSX.utils.aoa_to_sheet(data);
  sheet['!cols']=[16,46,62,18,12,26,40,28,18,26,26,28,48,90].map(wch=>({wch}));sheet['!autofilter']={ref:sheet['!ref']};
  XLSX.utils.book_append_sheet(book,sheet,'迁移结果');
  const bytes=XLSX.write(book,{type:'array',bookType:'xlsx',compression:true}),blob=new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=`迁移结果_${lastJob.startedAt.slice(0,10)}_${lastJob.id.slice(0,8)}.xlsx`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
}
$('#download').onclick=download;
$('#file').onchange=async()=>{try{
  $('#error').textContent='';const file=$('#file').files[0];if(!file)return;if(file.size>5*1024*1024)throw new Error('表格超过5MB，请拆分后导入');
  const bytes=new Uint8Array(await file.arrayBuffer());book=XLSX.read(bytes,{type:'array'});$('#filename').textContent=file.name;parse();
  let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));await chrome.storage.local.set({dxmFile:{name:file.name,base64:btoa(binary)}});
}catch(e){$('#error').textContent=e.message;book=null;}};
$('#mergeSplit').onchange=()=>{try{parse();$('#error').textContent='';}catch(e){$('#error').textContent=e.message;}};
$('#start').onclick=async()=>{try{
  $('#error').textContent='';const data=parse();const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  const options={startIndex:Number($('#startIndex').value),limit:Number($('#limit').value),modelNameFromNumber:$('#modelNameFromNumber').checked};
  if(options.startIndex>data.rows.length)throw new Error('起始产品超出表格范围');
  const res=await request({kind:'DXM_START',rows:data.rows,options,tabId:tab.id});if(!res.ok)throw new Error(res.error);await refresh();
}catch(e){$('#error').textContent=e.message;}};
$('#stop').onclick=async()=>{const r=await request({kind:'DXM_STOP'});if(!r.ok)$('#error').textContent=r.error;await refresh();};
async function refresh(){try{
  const result=await request({kind:'DXM_STATUS'});if(!result.ok)return;lastJob=result.job;if(!lastJob)return;
  const running=lastJob.state==='running'&&!lastJob.stop;$('#start').disabled=running;$('#file').disabled=running;$('#stop').disabled=!running;$('#download').disabled=false;
  $('#state').textContent=({running:'执行中',done:'已结束',stopped:'已停止',review:'需核对',error:'执行中断'})[lastJob.state]||lastJob.state;
  const selected=lastJob.rows.filter(r=>r.status!=='未执行');$('#progress').textContent=`${selected.filter(r=>['已上线','失败','发布失败','已跳过','已提交待确认','数据错误'].includes(r.status)).length} / ${selected.length} 条`;
  const logs=$('#logs');logs.replaceChildren();for(const entry of lastJob.logs.slice(-80)){const p=document.createElement('p');p.textContent=`${entry.time.split(' ').at(-1)} ${entry.message}`;logs.append(p);}logs.scrollTop=logs.scrollHeight;
  if(lastJob.error)$('#error').textContent=lastJob.error;
}catch(e){$('#error').textContent='扩展连接中断，请刷新店小秘页面后重试。';}}
(async()=>{const saved=(await chrome.storage.local.get('dxmFile')).dxmFile;if(saved){try{book=XLSX.read(Uint8Array.from(atob(saved.base64),c=>c.charCodeAt(0)),{type:'array'});$('#filename').textContent=saved.name;parse();}catch(e){$('#error').textContent=e.message;}}await refresh();})();
setInterval(refresh,1500);
