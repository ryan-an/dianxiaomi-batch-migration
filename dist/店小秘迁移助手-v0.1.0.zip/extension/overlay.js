(function(){
  'use strict';
  if(document.getElementById('dxm-migration-panel'))return;
  const host=document.createElement('div');host.id='dxm-migration-panel';host.style.cssText='position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
  const shadow=host.attachShadow({mode:'open'});
  shadow.innerHTML=`<style>:host{font-family:system-ui,'Microsoft YaHei',sans-serif}#shade{display:none;position:fixed;inset:0;background:#172d381a;pointer-events:all}aside{position:fixed;right:14px;bottom:14px;width:292px;max-height:285px;padding:13px;background:#fff;color:#263747;border:1px solid #d6e0e9;border-radius:12px;box-shadow:0 8px 40px #172d3833;font-size:12px;pointer-events:all;display:none}header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}b{font-size:13px}button{font:inherit;color:#166b62;background:#edf7f4;border:0;padding:6px 9px;border-radius:6px;cursor:pointer}#step{line-height:1.5;margin:8px 0;font-weight:600}#entries{font-size:11px;line-height:1.6;max-height:145px;overflow:auto;white-space:pre-line;word-break:break-word}.hint{color:#7c8795;font-size:10px;margin-top:9px}</style><div id="shade"></div><aside><header><b>迁移助手</b><button id="stop">停止执行</button></header><div id="step"></div><div id="entries"></div><div class="hint">执行时已锁定此页面。关闭扩展弹窗不会停止。</div></aside>`;
  document.documentElement.append(host);let locked=false;
  function guard(e){if(locked&&e.isTrusted&&!e.composedPath().includes(host)){e.preventDefault();e.stopImmediatePropagation();}}
  for(const type of ['click','dblclick','pointerdown','pointerup','mousedown','mouseup','touchstart','keydown','wheel','contextmenu'])document.addEventListener(type,guard,{capture:true,passive:false});
  shadow.getElementById('stop').onclick=()=>chrome.runtime.sendMessage({kind:'DXM_STOP'});
  async function refresh(){try{
    const result=await chrome.runtime.sendMessage({kind:'DXM_STATUS'}),job=result.job;
    locked=!!(result.owner&&job?.state==='running'&&!job.stop);
    shadow.getElementById('shade').style.display=locked?'block':'none';shadow.querySelector('aside').style.display=locked?'block':'none';
    if(locked){shadow.getElementById('step').textContent=job.step;const entries=shadow.getElementById('entries');entries.textContent=job.logs.slice(-8).map(e=>e.message).join('\n');entries.scrollTop=entries.scrollHeight;}
  }catch{locked=false;shadow.getElementById('shade').style.display='none';shadow.querySelector('aside').style.display='none';}}
  refresh();setInterval(refresh,1500);
})();
