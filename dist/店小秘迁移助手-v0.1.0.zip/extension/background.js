importScripts('core.js','workflow.js');
let job=null,busy=false,loadPromise=null;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function save(){if(job)await chrome.storage.local.set({dxmJob:job});}
async function load(){
  if(loadPromise)return loadPromise;
  loadPromise=(async()=>{job=(await chrome.storage.local.get('dxmJob')).dxmJob||null;
  if(job?.state==='running'){
    job.state='review';job.error='浏览器或后台曾中断，请核对页面。为避免重复发布，不自动重跑。';
    for(const r of job.rows)if(!['未执行','数据错误','失败','已跳过','已上线','已提交待确认'].includes(r.status)){r.status='待人工核对';r.error=job.error;}
    await save();
  }})();return loadPromise;
}
function allowed(url){const u=new URL(url);return u.origin==='https://www.dianxiaomi.com'&&/^\/web\/(amazon\/|productCrawl\/)/.test(u.pathname);}
async function raw(action,args={}){
  if(job.stop&&action!=='stop')throw new Error('用户已停止');
  const result=await chrome.tabs.sendMessage(job.tabId,{kind:'DXM_ACTION',action,args,runId:job.id});
  if(!result?.ok)throw new Error(result?.error||'页面没有返回执行结果');return result.data;
}
const io={save,sleep:pause,
  async call(action,args={},risky=false){
    if(job.stop)throw new Error('用户已停止');
    if(risky){job.intent={action,time:new Date().toISOString()};await save();}
    try{const data=await raw(action,args);job.intent=null;await save();return data;}
    catch(e){if(risky)e.uncertain=true;throw e;}
  },
  async open(url){
    if(!allowed(url))throw new Error('不允许跳转到店小秘工作流之外的地址');
    if(job.stop)throw new Error('用户已停止');
    await chrome.tabs.update(job.tabId,{url});
    const end=Date.now()+45000;let error;
    while(Date.now()<end){
      if(job.stop)throw new Error('用户已停止');
      try{
        const tab=await chrome.tabs.get(job.tabId);
        if(tab.status==='complete'&&new URL(tab.url).pathname===new URL(url).pathname){const ready=await raw('ready');if(new URL(ready.url).pathname===new URL(url).pathname)return;}
      }catch(e){error=e;}
      await pause(500);
    }
    throw new Error(`页面未准备好：${error?.message||url}`);
  }
};
chrome.runtime.onMessage.addListener((m,s,reply)=>{
  (async()=>{
    await load();
    if(m.kind==='DXM_STATUS')return {ok:true,job,owner:s.tab?.id===job?.tabId};
    if(m.kind==='DXM_STOP'){
      if(job&&busy){job.stop=true;await save();try{await chrome.tabs.sendMessage(job.tabId,{kind:'DXM_ACTION',action:'stop'});}catch{}}
      return {ok:true};
    }
    if(m.kind==='DXM_START'){
      if(busy)throw new Error('已有批次正在执行');
      busy=true;
      try {
      const tab=await chrome.tabs.get(m.tabId);
      if(!tab.url?.startsWith('https://www.dianxiaomi.com/web/'))throw new Error('请在店小秘页面开始');
      if(!Array.isArray(m.rows)||!m.rows.length)throw new Error('没有有效数据');
      const limit=Number(m.options.limit),start=Number(m.options.startIndex||1)-1;
      if(!Number.isInteger(limit)||limit<1||!Number.isInteger(start)||start<0)throw new Error('执行条数和起始行必须为正整数');
      const rows=structuredClone(m.rows);
      for(let i=0;i<rows.length;i++){
        const r=rows[i];r.history=[];
        if(!r.error){DXMCore.sourceKey(r.source);r.status=i>=start&&i<start+limit?'待执行':'未执行';}
      }
      job={id:crypto.randomUUID(),state:'running',rows,logs:[],options:m.options,tabId:m.tabId,startedAt:new Date().toISOString(),step:'准备',stop:false,intent:null};
      await save();
      setTimeout(()=>new DXMWorkflow(job,io).run().finally(()=>{busy=false;}),0);
      return {ok:true};
      }catch(e){busy=false;throw e;}
    }
    throw new Error('未知请求');
  })().then(reply,e=>reply({ok:false,error:e.message}));return true;
});
chrome.tabs.onRemoved.addListener(async tabId=>{await load();if(job?.tabId===tabId&&busy){job.stop=true;job.error='执行标签页已关闭';await save();}});
