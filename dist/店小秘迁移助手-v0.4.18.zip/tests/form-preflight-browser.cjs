// Replay captured form DOM offline; no live products or requests are used.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright'),workspace=path.resolve(__dirname,'..');
(async()=>{
  const browser=await chromium.launch({channel:'msedge',headless:true});
  try{
    const page=await browser.newPage();
    await page.route('**/*',async route=>{
      const url=new URL(route.request().url()),file=path.resolve(workspace,'.'+decodeURIComponent(url.pathname));
      if(url.hostname!=='migration.test'||!file.startsWith(workspace+path.sep)||!fs.existsSync(file)){await route.abort();return;}
      const type=path.extname(file)==='.html'?'text/html; charset=utf-8':path.extname(file)==='.js'?'text/javascript; charset=utf-8':path.extname(file)==='.json'?'application/json':'text/plain; charset=utf-8';
      await route.fulfill({body:fs.readFileSync(file),contentType:type});
    });
    async function setup(){await page.goto('http://migration.test/tests/fixture.html');await page.waitForFunction(()=>document.getElementById('result').textContent.startsWith('DOM 已加载'));}
    async function fill(){return page.evaluate(async()=>{
      const result=await DXMAdapter.commands.fill({record,modelName:record.data['Model Number']});
      // Captured HTML has a currency error; the fixture has no Vue validator.
      const item=document.getElementById('form_item_list_price.0.currency').closest('.ant-form-item');
      if(item.querySelector('.ant-select-selection-item')?.textContent==='GBP(英镑)')item.querySelectorAll('.ant-form-item-explain-error').forEach(e=>e.remove());
      return result;
    });}
    await setup();
    // IDs and placeholders vary by category; labels must still locate these fields.
    await page.evaluate(()=>{
      record.data['制造商']='Wrong manufacturer';
      for(const selector of ['input[placeholder="请输入制造商"]','[id="form_item_model_number.0.value"]','[id="form_item_model_name.0.value"]']){
        const field=document.querySelector(selector);field.id='changed-'+field.id;field.removeAttribute('placeholder');
      }
    });
    await fill();
    let check=await page.evaluate(async()=>{
      const result=await DXMAdapter.commands.preflight({record});
      const values=Object.fromEntries([...document.querySelectorAll('.ant-form-item')].filter(e=>/^(制造商|Model Number|Model Name)/.test(e.querySelector('.ant-form-item-label')?.textContent.trim())).map(e=>[e.querySelector('.ant-form-item-label').textContent.trim(),e.querySelector('input')?.value]));
      return {result,values};
    });assert.ok(check.result.checked.includes('制造商'));assert.deepEqual(Object.values(check.values),['Preocea','/01','/01']);
    // Lose values after initial fill, then replace nodes on the first repair attempt.
    check=await page.evaluate(async()=>{
      let replaced=false;
      const items=[...document.querySelectorAll('.ant-form-item')].filter(e=>/^(制造商|Model Number|Model Name)/.test(e.querySelector('.ant-form-item-label')?.textContent.trim()));
      for(const item of items){const field=item.querySelector('input');field.value='';field.addEventListener('input',()=>{if(replaced)return;replaced=true;const fresh=field.cloneNode(true);fresh.value='';field.replaceWith(fresh);});}
      const result=await DXMAdapter.commands.preflight({record});return {result,replaced};
    });assert.equal(check.replaced,true);assert.deepEqual(check.result.repaired,['制造商','Model Number','Model Name']);
    // An independent Model Name remains authoritative; missing manufacturer data uses brand.
    check=await page.evaluate(async()=>{delete record.data['制造商'];record.data['Model Name']='Distinct model';const result=await DXMAdapter.commands.preflight({record});return result;});assert.ok(check.repaired.includes('Model Name'));
    // Missing source model data cannot be invented or sent empty.
    const missing=await page.evaluate(async()=>{
      delete record.data['Model Number'];delete record.data['Model Name'];
      for(const item of [...document.querySelectorAll('.ant-form-item')].filter(e=>/^(Model Number|Model Name)/.test(e.querySelector('.ant-form-item-label')?.textContent.trim())))item.querySelector('input').value='';
      try{await DXMAdapter.commands.preflight({record});return '';}catch(e){return e.message;}
    });assert.match(missing,/原表型号数据.*缺失/);
    await setup();await fill();
    const otherRequired=await page.evaluate(async()=>{
      document.getElementById('app').insertAdjacentHTML('beforeend','<div class="ant-form-item"><div class="ant-form-item-label"><label class="ant-form-item-required">Other attribute</label></div><input></div>');
      try{await DXMAdapter.commands.preflight({record});return '';}catch(e){return e.message;}
    });assert.match(otherRequired,/Other attribute.*未填写/);
    await setup();await fill();
    const rejected=await page.evaluate(async()=>{
      const field=document.getElementById('form_item_model_name.0.value');field.value='';field.addEventListener('input',()=>{field.value='';});
      try{await DXMAdapter.commands.preflight({record});return '';}catch(e){return e.message;}
    });assert.match(rejected,/写入后未保留.*阻止提交/);
    console.log('PASS：真实表单DOM中品牌复制到制造商、型号/型号名称填写、标签定位、重绘后重新定位补填、独立型号名称、原表缺值阻止提交、其他必填项检查、拒绝保留输入时阻止提交。');
  }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
