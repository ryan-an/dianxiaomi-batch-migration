'use strict';
const app=document.getElementById('app'),out=document.getElementById('result');
const assert=(value,message)=>{if(!value)throw new Error(message);};
function setup(count,already=false){
  let clicks=0,confirmed=0;
  app.innerHTML='<div class="ant-select"><input id="form_item_category"><span class="ant-select-selection-item">'+(already?'已选择分类':'')+'</span></div><button id="auto">自动识别产品类型</button>';
  document.getElementById('auto').onclick=()=>{
    clicks++;const m=document.createElement('div');m.className='ant-modal';m.innerHTML='<h3>Amazon推荐产品类型</h3>'+Array.from({length:count},(_,i)=>'<label><input type="radio" name="category" '+(!i?'checked':'')+'>分类'+i+'</label>').join('')+'<button>确定</button>';app.append(m);
    m.querySelector('button').onclick=()=>{confirmed++;app.querySelector('.ant-select-selection-item').textContent='唯一推荐分类';m.remove();};
  };
  return {clicks:()=>clicks,confirmed:()=>confirmed};
}
document.getElementById('test').onclick=async()=>{try{
  const existing=setup(1,true);const kept=await DXMAdapter.commands.ensureCategory();assert(!kept.changed&&existing.clicks()===0,'已有分类被修改');
  const single=setup(1);const filled=await DXMAdapter.commands.ensureCategory();assert(filled.changed&&single.clicks()===1&&single.confirmed()===1,'唯一推荐未确认');
  const multi=setup(2);let rejected=false;try{await DXMAdapter.commands.ensureCategory();}catch(e){rejected=/2 个分类/.test(e.message);}assert(rejected&&multi.confirmed()===0,'多分类错误确认了默认项');
  out.textContent='PASS：已有分类保留；空分类点击识别一次；唯一推荐确认后等待加载；多推荐不确认默认项。';
}catch(e){out.textContent='FAIL：'+e.message;}};
