(function(root){
  'use strict';
  const C=root.DXMCore;
  class Workflow {
    constructor(job,io){this.job=job;this.io=io;}
    async log(message,records=[]){
      const entry={time:new Date().toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false}),message};
      this.job.logs.push(entry);if(this.job.logs.length>1000)this.job.logs.shift();
      for(const r of records)r.history.push(entry);
      await this.io.save();
    }
    guard(){if(this.job.stop)throw new Error('用户已停止');}
    async step(name,rs){this.guard();this.job.step=name;for(const r of rs)r.step=name;await this.log(name,rs);}
    async scan(){
      await this.io.call('firstPage');const collected=new Map(),seen=new Set();
      for(let page=0;page<500;page++){
        this.guard();const s=await this.io.call('snapshot');
        if(seen.has(s.signature)&&s.hasNext)throw new Error('分页没有前进，已停止扫描');seen.add(s.signature);
        for(const r of s.rows)collected.set(r.id,r);
        if(!s.hasNext)return [...collected.values()];
        await this.io.call('nextPage');
      }
      throw new Error('列表超过500页，请缩小筛选范围');
    }
    async progress(rs){
      const end=Date.now()+15*60*1000;let previous='';
      while(Date.now()<end){
        this.guard();const p=await this.io.call('progress');
        if(p.text!==previous){await this.log(p.text,rs);previous=p.text;}
        if(p.done){await this.io.call('closeProgress');return p;}
        await this.io.sleep(1500);
      }
      throw new Error('操作15分钟未完成，请检查店小秘进度');
    }
    async pageBatches(records,idField,command,extra={}){
      const pending=new Set(records.map(r=>r[idField]));
      while(pending.size){
        this.guard();await this.io.call('firstPage');let found=false;
        for(let n=0;n<500;n++){
          const snap=await this.io.call('snapshot'),ids=snap.rows.map(r=>r.id).filter(k=>pending.has(k));
          if(ids.length){
            const members=records.filter(r=>ids.includes(r[idField]));
            await this.log(`本页处理 ${members.length} 个本批次产品`,members);
            const result=await this.io.call(command,{ids,...extra},true);
            if(command==='claim'||command==='retry')await this.progress(members);
            else if(result.text)await this.log(result.text,members);
            for(const value of ids)pending.delete(value);
            found=true;break;
          }
          if(!snap.hasNext)break;await this.io.call('nextPage');
        }
        if(!found)throw new Error(`本批次还有 ${pending.size} 条在当前列表无法定位，请核对状态`);
      }
    }
    fail(r,e){r.status='失败';r.error=e.message||String(e);}
    same(a,b){try{return C.sourceKey(a)===C.sourceKey(b);}catch{return false;}}
    matchProduct(list,r,byId=false){
      return C.uniqueMatch(list,x=>(!byId||x.id===r.productId)&&this.same(x.source,r.source)&&C.norm(x.title)===C.norm(r.title)&&x.text.includes(`「${r.targetShop}」`)&&x.text.includes(r.site),`产品 ${r.source}`);
    }
    async runGroup(group){
      const rs=group.filter(r=>r.status==='待执行');if(!rs.length)return;
      await this.step(`检查 ${rs[0].targetShop} / ${rs[0].site} 的已有采集记录`,rs);
      await this.io.open('https://www.dianxiaomi.com/web/productCrawl/dataAcquisition');await this.io.call('acquisitionTab',{name:'全部'});
      const before=await this.scan();
      // Do not adopt old account data, including records from manual testing.
      for(const r of rs)if(before.some(x=>this.same(x.source,r.source))){r.status='已跳过';r.error='来源链接已有采集记录，未重复采集或认领';await this.log(r.error,[r]);}
      const work=rs.filter(r=>r.status==='待执行');if(!work.length)return;
      await this.step(`开始采集 ${work.length} 条链接`,work);
      await this.io.call('collect',{sources:work.map(r=>r.source)},true);await this.progress(work);
      await this.io.call('acquisitionTab',{name:'采集失败'});
      const failed=await this.scan(),retry=[];
      for(const r of work){
        const matches=failed.filter(x=>this.same(x.source,r.source));
        if(matches.length===1){r.collectorId=matches[0].id;r.retryCount=1;retry.push(r);}
        else if(matches.length>1)this.fail(r,new Error('采集失败列表中来源重复，不能确定要重试的条目'));
      }
      if(retry.length){await this.step(`批量重试 ${retry.length} 条，每条只重试一次`,retry);await this.pageBatches(retry,'collectorId','retry');}
      await this.io.call('acquisitionTab',{name:'未认领'});const crawled=await this.scan();
      for(const r of work.filter(r=>r.status!=='失败')){
        try{
          const m=C.uniqueMatch(crawled,x=>this.same(x.source,r.source)&&!before.some(b=>b.id===x.id),'采集链接和标题映射');
          if(!m.title)throw new Error('采集产品标题为空');r.collectorId=m.id;r.title=m.title;r.status='采集完成';
          await this.log(`已对应标题：${r.title}`,[r]);
        }catch(e){this.fail(r,e);}
      }
      const good=work.filter(r=>r.status==='采集完成');if(!good.length)return;
      await this.step(`批量认领到 [${good[0].site}]${good[0].targetShop}`,good);
      await this.pageBatches(good,'collectorId','claim',{shop:good[0].targetShop,site:good[0].site});
      await this.io.open('https://www.dianxiaomi.com/web/amazon/pageList/draft');const draft=await this.scan();
      for(const r of good){try{const m=this.matchProduct(draft,r);r.productId=m.id;r.status='已认领';}catch(e){this.fail(r,e);}}
      const claimed=good.filter(r=>r.status==='已认领');if(!claimed.length)return;
      await this.step('将本批次产品批量移入待发布',claimed);await this.pageBatches(claimed,'productId','move');
      await this.io.open('https://www.dianxiaomi.com/web/amazon/pageList/offline');const offline=await this.scan();
      for(const r of claimed){
        this.guard();
        try{
          await this.step(`填写：${r.title}`, [r]);
          const m=this.matchProduct(offline,r,true);
          if(!m.editUrl)throw new Error('待发布产品没有编辑链接');
          await this.io.open(m.editUrl);const filled=await this.io.call('fill',{record:r,modelName:this.job.options.modelNameFromNumber?r.data['Model Number']:''});await this.log(`已填写：${filled.written.join('、')}`,[r]);
          await this.step('保存并发布',[r]);await this.io.call('publish',{},true);
          let result;const end=Date.now()+60000;
          do{this.guard();result=await this.io.call('publishStatus');if(result.done)break;await this.io.sleep(1000);}while(Date.now()<end);
          if(!result.done){const e=new Error('提交发布后的结果无法确认，请核对平台，禁止自动重复提交');e.uncertain=true;throw e;}
          if(result.failed)throw new Error(result.text);
          if(!result.submitted)throw new Error('没有收到产品已提交发布的确认');
          r.status='已提交待确认';r.publishedAt=new Date().toISOString();await this.log('店小秘已接收发布，等待在线列表确认',[r]);
        }catch(e){if(e.uncertain||this.job.stop)throw e;this.fail(r,e);await this.log(`本条失败：${r.error}`,[r]);}
      }
    }
    async verifyPublished(){
      const submitted=this.job.rows.filter(r=>r.status==='已提交待确认');
      if(!submitted.length)return;
      await this.step('核对在线列表和发布失败列表',submitted);
      for(const r of submitted){
        this.guard();await this.io.open('https://www.dianxiaomi.com/web/amazon/pageList/online');await this.io.call('searchTitle',{title:r.title});
        const online=await this.scan(),found=online.filter(x=>x.id===r.productId&&this.same(x.source,r.source));
        if(found.length===1){r.status='已上线';r.step='完成';r.targetUrl=found[0].links.find(x=>/amazon\.co\.uk\/dp\//.test(x.href))?.href||'';await this.log('已在店小秘在线产品列表确认（不代表已有可售库存）',[r]);continue;}
        await this.io.open('https://www.dianxiaomi.com/web/amazon/pageList/offline');await this.io.call('listState',{name:'发布失败'});await this.io.call('searchTitle',{title:r.title});
        const failed=(await this.scan()).filter(x=>x.id===r.productId&&this.same(x.source,r.source));
        if(failed.length===1){r.status='发布失败';r.error=failed[0].text.slice(0,2000);await this.log('平台返回发布失败，详细原因已记录',[r]);}
        else await this.log('平台仍在处理，结果表保留“已提交待确认”，不会重复提交',[r]);
      }
    }
    async run(){
      try{
        const groups=new Map();for(const r of this.job.rows.filter(r=>r.status==='待执行')){const k=`${r.targetShop}|${r.site}`;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);}
        for(const group of groups.values()){
          try{await this.runGroup(group);}catch(e){if(e.uncertain||this.job.stop)throw e;for(const r of group)if(!['失败','已跳过','已提交待确认','已上线'].includes(r.status))this.fail(r,e);await this.log(`本店铺批次中止：${e.message}`,group);}
        }
        await this.verifyPublished();this.job.state='done';await this.log('本批次结束，可以下载结果表');
      }catch(e){
        this.job.state=e.uncertain?'review':this.job.stop?'stopped':'error';this.job.error=e.message;
        for(const r of this.job.rows)if(!['未执行','数据错误','失败','已跳过','已上线','已提交待确认','发布失败'].includes(r.status)){r.status=e.uncertain?'待人工核对':'已停止';r.error=e.message;}
        await this.log(e.uncertain?`提交状态不确定，已停止：${e.message}`:`已停止：${e.message}`);
      }finally{await this.io.save();}
    }
  }
  root.DXMWorkflow=Workflow;if(typeof module!=='undefined')module.exports=Workflow;
})(globalThis);
