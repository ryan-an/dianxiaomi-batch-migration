(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  let parsed=null,fileInfo=null,job=null,reading=false,starting=false,refreshing=false,error='',connectionError='';
  let logSignature='',lastLogJob='';
  const busy=()=>job?.state==='running';
  const node=(tag,text,className)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(className)n.className=className;return n;};
  function parseBook(book){
    parsed=DXMCore.parseWorkbook(book,XLSX,{mergeSplit:true,shopAliases:DXMCore.alias});
  }
  function renderLogs(){
    const entries=job?.logs||[],signature=JSON.stringify(entries);if(signature===logSignature)return;logSignature=signature;
    const box=$('logs'),follow=box.scrollHeight-box.scrollTop-box.clientHeight<35,top=box.scrollTop;box.replaceChildren();
    if(!entries.length)box.append(node('p','开始后显示操作进度。','empty'));
    for(const entry of entries){const line=node('p',null,'entry'),time=node('time',(entry.time||'').match(/\d{1,2}:\d{2}:\d{2}/)?.[0]||'');time.title=entry.time||'';line.append(time,node('span',entry.message));box.append(line);}
    $('logCount').textContent=entries.length?`${entries.length} 条`:'';
    if(follow)box.scrollTop=box.scrollHeight;else box.scrollTop=top;
    $('latestLog').hidden=follow||!entries.length;
    if(job?.id!==lastLogJob&&busy()){$('logDetails').open=true;lastLogJob=job.id;box.scrollTop=box.scrollHeight;}
  }
  function render(){
    const s=DXMUI.summary(job),valid=parsed?.rows.filter(r=>!r.error).length||0,locked=busy()||reading||starting;
    $('upload').disabled=locked;$('start').disabled=locked||!valid||!!connectionError;
    $('startLabel').textContent=starting?'正在开始…':busy()?'执行中':'开始执行';
    $('stop').hidden=!busy();$('stop').disabled=s.stopping;$('stop').textContent=s.stopping?'停止中…':'停止';
    $('download').disabled=!job?.rows?.length;
    $('filename').textContent=fileInfo?.name||'上传迁移表格';$('chooseFile').textContent=fileInfo?'更换':'选择文件';
    $('fileMeta').textContent=parsed?`已识别 ${parsed.rows.length} 条产品`:fileInfo?'表格未能解析，请重新上传':'支持 XLS / XLSX，也可以拖入文件';
    const invalid=(parsed?.rows.length||0)-valid;$('parseHint').hidden=!invalid;$('parseHint').textContent=`${invalid} 条数据需要处理，原因会保留在结果表。`;
    $('status').dataset.tone=connectionError||error?'error':s.tone;
    $('status').textContent=reading?'正在读取表格…':starting?'正在准备执行…':connectionError?'后台连接失败':error?'需要处理':job?s.label:parsed?`准备就绪，将处理全部 ${parsed.rows.length} 条产品`:'请先上传表格';
    const message=error||connectionError||job?.error||'';$('message').hidden=!message;$('message').textContent=message;
    $('progress').hidden=!job;$('progressFill').style.width=`${s.percent}%`;$('progressBar').setAttribute('aria-valuenow',s.percent);
    $('progressText').textContent=`已处理 ${s.processed} / ${s.total} 条`;
    $('resultText').textContent=[`上线 ${s.success}`,`待确认 ${s.pending}`,`需处理 ${s.failed+s.review}`,s.skipped?`已跳过 ${s.skipped}`:''].filter(Boolean).join(' · ');
    renderLogs();
  }
  async function importFile(file){
    if(!file||busy()||starting||reading)return;
    if(!/\.xlsx?$/i.test(file.name)){error='请选择 .xls 或 .xlsx 表格。';render();return;}
    if(file.size>5*1024*1024){error='请使用 5 MB 以内的表格。';render();return;}
    reading=true;error='';render();
    try{
      const bytes=new Uint8Array(await file.arrayBuffer()),book=XLSX.read(bytes,{type:'array'});
      parseBook(book);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
      fileInfo={name:file.name,base64:btoa(binary)};await chrome.storage.local.set({dxmFile:fileInfo});
    }catch(e){parsed=null;error=`表格导入失败：${e.message}`;}finally{reading=false;$('file').value='';render();}
  }
  async function refresh(){
    if(refreshing)return;refreshing=true;
    try{const r=await chrome.runtime.sendMessage({kind:'DXM_STATUS'});if(!r?.ok)throw new Error(r?.error||'没有收到后台响应');job=r.job||null;connectionError='';}
    catch(e){connectionError=`${e.message}。请重新加载扩展后，再打开弹窗。`;}
    finally{refreshing=false;render();}
  }
  $('chooseFile').onclick=()=>$('file').click();$('file').onchange=()=>importFile($('file').files[0]);
  $('dropzone').ondragover=e=>{e.preventDefault();if(!busy()&&!starting&&!reading)$('dropzone').classList.add('dragging');};
  $('dropzone').ondragleave=()=>$('dropzone').classList.remove('dragging');
  $('dropzone').ondrop=e=>{e.preventDefault();$('dropzone').classList.remove('dragging');importFile(e.dataTransfer.files[0]);};
  $('start').onclick=async()=>{
    if(busy()||starting||!parsed?.rows.some(r=>!r.error))return;
    starting=true;error='';render();
    try{const r=await chrome.runtime.sendMessage({kind:'DXM_START',rows:parsed.rows});if(!r?.ok)throw new Error(r?.error||'任务没有启动');await refresh();}
    catch(e){error=e.message;}finally{starting=false;render();}
  };
  $('stop').onclick=async()=>{
    $('stop').disabled=true;
    try{const r=await chrome.runtime.sendMessage({kind:'DXM_STOP'});if(!r?.ok)throw new Error(r?.error||'停止请求没有发送');await refresh();}
    catch(e){error=e.message;render();}
  };
  $('download').onclick=()=>{
    if(!job?.rows?.length)return;
    try{const sheet=XLSX.utils.aoa_to_sheet(DXMCore.resultTable(job.rows));sheet['!cols']=[{wch:15},{wch:48},{wch:60},{wch:20},{wch:10},{wch:22},{wch:55},{wch:25},{wch:20},{wch:25},{wch:25},{wch:28},{wch:48},{wch:80}];const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,sheet,'迁移结果');XLSX.writeFile(book,`迁移结果_${new Date().toISOString().slice(0,10)}.xlsx`);}
    catch(e){error=`结果导出失败：${e.message}`;render();}
  };
  $('latestLog').onclick=()=>{$('logs').scrollTop=$('logs').scrollHeight;$('latestLog').hidden=true;};
  $('logs').onscroll=()=>{$('latestLog').hidden=$('logs').scrollHeight-$('logs').clientHeight-$('logs').scrollTop<35;};
  async function init(){
    try{const stored=await chrome.storage.local.get('dxmFile');if(stored.dxmFile){fileInfo=stored.dxmFile;parseBook(XLSX.read(fileInfo.base64,{type:'base64'}));}}
    catch(e){error=`上次表格未能恢复，请重新上传：${e.message}`;}
    await refresh();setInterval(refresh,1500);
  }
  init();
})();
