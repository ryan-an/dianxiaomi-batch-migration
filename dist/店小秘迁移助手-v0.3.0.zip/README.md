# 店小秘批量迁移助手

已手动验证一个产品从采集、批量认领、采集箱移入待发布、编辑到在线列表的完整流程。仅第1条真实执行，其余9条保留给后续测试。

## 安装和开始

1. 解压发布 ZIP，打开 Chrome 的扩展管理页 `chrome://extensions`（Edge 为 `edge://extensions`）。
2. 打开“开发者模式” → “加载已解压的扩展程序”，选择包含 `manifest.json` 的 `extension` 文件夹。
3. 在安装扩展的同一个浏览器里登录店小秘，再刷新店小秘页面。
4. 点击工具栏“店小秘批量迁移助手”，上传或拖入 `迁移数据.xls`。
5. 点击“开始执行”，**默认处理整张表**。插件自动匹配店铺、选择当前或最近使用的店小秘标签页，没有范围和映射设置。第1条此前已手动完成，有历史采集记录的来源会自动跳过。
6. 弹窗显示进度和日志；结束后点击“下载结果”，得到 XLSX，采集ID和产品ID保留为文本，避免 Excel 改写长数字。
7. 关闭弹窗后任务继续执行，点击插件图标即可再次查看进度。执行期间可点击“停止”。

从旧版更新：使用新版完整的 `extension` 文件夹，在扩展管理页点击“重新加载”（或重新选择该文件夹），关闭旧控制窗口并刷新店小秘页面，再点击插件图标。不要在批次运行过程中更新。

## v0.3 精简界面

使用浏览器原生的 400px 小弹窗，仅保留上传、开始、停止、下载和折叠日志。

- 执行范围固定为整表，不读取旧版保存的范围或店铺编辑设置。
- 店铺按原表自动匹配，保留已确认的英国店铺别名；跨表补齐、Model Name 等填写规则固定在后台处理。
- 自动选择当前窗口的店小秘页面；没有当前页面时选择最近使用的店小秘标签页。未登录或未打开时，在弹窗里提示。
- 移除 `panel-window.js` 及 `action.onClicked` 独立窗口打开链路，由 manifest 的 `default_popup` 直接打开。
- 后台保存失败不会创建假运行状态；意外执行错误会进入“待核对”，并在界面中显示原因。

界面截图及验证范围见 [UI改版说明](docs/UI改版说明.md)。这次改版没有执行任何真实产品操作。

插件是标准 Chromium Manifest V3 扩展，需要安装到支持此类扩展的 Chrome / Edge 浏览器中。此次在 Codex 内置浏览器进行的是手动流程实测，没有给内置浏览器安装扩展，也没有用扩展执行剩余9条。

## 已确认的填写规则

- 表格 `万万欣UK|英国` 固定映射到实际店铺 `[英国]万万欣DE`，其他店铺按原表店名和站点匹配。
- Sheet1 最后4条链接与 Sheet2 的4行数据按顺序补齐，结果保留两个来源位置；结构不一致就报错。
- UPC 去掉首尾空格，保留文本标识符；数字0属于有效数据。其他空单元格跳过。
- 先清空“价格信息”中的产品数量，再切换配送为 FBA。此处指库存，不是产品属性中的 Number of Items。
- 型号名称 Model Name 沿用同一行 Model Number（用户已确认），优先使用原表的独立 Model Name。品牌取原表“品牌”。
- 原产地 China（中国）、需要电池 No（不）、危险商品规管仅 Not Applicable（不适用），按用户图片填写。
- 英国 List Price 对应页面 `List Price with Tax`；长度单位中的德语 `Zentimeter(厘米)` 与英国 `Centimetres(厘米)` 作为同一单位匹配。
- 采集会留下无起止日期的促销价，这会阻止发布；插件清除这种不完整促销价并记入日志。已有完整起止时间的促销不改。

## 批次和错误处理

- 同店铺、同站点分组，链接以换行分隔，批量采集；失败项按当前页批量重试一次。
- 只勾选本批次产品，翻页处理，始终核对原链接、采集标题、采集 ID 和产品 ID；标题不是平台保证唯一的键。
- 发现来源链接已经有历史采集记录时跳过，避免再次使用手动测试产品。不会自动接管旧的半成品或旧失败项。
- 同一来源匹配多条、店铺/站点不一致或缺字段，会停止该条或该店铺组并记明步骤，不猜数据。
- 发布结果区分“已提交待确认”“已上线”“发布失败”。“已上线”表示在店小秘在线列表找到同产品 ID，不代表有可售库存。
- 页面用户点击和键盘操作在执行期间被锁定，点击停止并等待当前步骤结束后解除锁定。自动化生成的 DOM 事件仍可执行；浏览器地址栏、关闭标签等浏览器自身行为不受页面控制。
- 点击停止后不会启动新步骤；已经提交给店小秘的操作可能继续由服务器处理，插件不进行回滚或重复提交。
- 批次状态保存在 `chrome.storage.local`。刷新、关闭浏览器或后台意外中断后会标记“需核对”，不自动重复提交。结果表仍可下载；需要人工核对后开启新批次。

## 测试范围和文件

- `docs/实测记录.md`：真实操作记录、选择器、结果和范围。
- `docs/evidence/`：逐字段原始 DOM、列表和弹窗片段、截图。大表单按字段分别保存，避免字符串截断；`editor-form.html` 只拼接所需字段的完整片段。
- `docs/实现方案.md`：代码模块及数据流。
- `outputs/单条实测结果.xlsx`：第1条真实结果和另外9条“未执行”的明细；另有 CSV 和 JSON 版本保留日志。
- `tests/`：数据/流程测试、使用真实 DOM 片段的本地表单测试、页面锁定测试。

扩展代码已做本地测试，尚未作为已安装的扩展运行真实批次。不同类目的容量控件和额外必填属性可能不同，当前只真实验证了 S形钩；未匹配的容量结构或新的必填项会如实报错。没有制造失败产品来测试远端重试；重试菜单 DOM 已核实，重试次数通过本地流程测试验证。

## 本地开发验证

使用 Node.js 24：

```powershell
node --test --test-isolation=none tests/core.test.cjs tests/workflow.test.cjs tests/ui-model.test.cjs tests/work-target.test.cjs tests/background.test.cjs
node tests/build-fixtures.cjs
node tests/verify-package.cjs
python -m http.server 8765 --bind 127.0.0.1
```

本地浏览器打开 `/tests/fixture.html`、`/tests/lock.html`、`/tests/ui-gallery.html?width=400&state=ready`。UI 演示支持 `idle`、`ready`、`running`、`done`、`review`、`error`、`stopped`、`notabs`、`start-error`、`backend-error`。这些页面不会执行店小秘操作。UI 预览中的 Chrome API 是模拟值，导出按钮只检查生成的 XLSX 内容，不触发下载；不等于扩展安装测试。

## 依赖和官方资料

表格解析库 SheetJS CE 0.20.3 随扩展本地打包，许可证见 `extension/vendor/LICENSE-SheetJS.txt`，运行时不加载远程脚本。扩展仅申请本地存储和 `www.dianxiaomi.com` 的站点权限，不请求 Cookie、密码、调试器或任意网站权限，不调用店小秘私有接口。

- [Chrome content scripts](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts)
- [SheetJS standalone browser scripts](https://docs.sheetjs.com/docs/getting-started/installation/standalone/)
