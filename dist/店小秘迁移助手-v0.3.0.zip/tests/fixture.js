'use strict';
const app=document.querySelector('#app'),out=document.querySelector('#result');let record,original;
const assert=(yes,message)=>{if(!yes)throw new Error(message);};
const selectValues={
  '配送渠道':['FBM','FBA'],'Item Package Weight Unit(包装重量单位)':['Grams(克)','Kilograms(公斤)']
};
function initSelections(){
  for(const box of app.querySelectorAll('.ant-select')){
    box.querySelector('.ant-select-selector')?.addEventListener('click',()=>{
      document.querySelector('.ant-select-dropdown')?.remove();
      const label=box.closest('.ant-form-item')?.querySelector('.ant-form-item-label')?.textContent.replace(/[\s*:：]/g,'');
      const values=selectValues[label]||[box.querySelector('.ant-select-selection-item')?.textContent||''];
      const dropdown=document.createElement('div');dropdown.className='ant-select-dropdown';
      for(const value of values){const item=document.createElement('div');item.className='ant-select-item-option';item.textContent=value;item.onclick=()=>{box.querySelector('.ant-select-selection-item').textContent=value;dropdown.remove();if(label==='配送渠道'){
        const quantity=app.querySelector('#fixture-quantity');if(value==='FBA')quantity?.remove();
      }};dropdown.append(item);}document.body.append(dropdown);
    });
  }
}
async function setup(){
  record=await (await fetch('/tests/fixture-data.json')).json();original=await (await fetch('/docs/evidence/editor-form.html')).text();app.innerHTML=original;
  // The captured form has FBA selected. Recreate the observed FBM quantity field to verify order.
  const item=[...app.querySelectorAll('.ant-form-item')].find(e=>e.querySelector('.ant-form-item-label')?.textContent.trim()==='产品数量');item?.remove();
  const q=document.createElement('div');q.id='fixture-quantity';q.className='ant-form-item';q.innerHTML='<div class="ant-form-item-label"><label>产品数量</label></div><input placeholder="请输入产品数量" value="18">';app.append(q);
  const delivery=[...app.querySelectorAll('.ant-form-item')].find(e=>e.querySelector('.ant-form-item-label')?.textContent.trim()==='配送渠道');delivery.querySelector('.ant-select-selection-item').textContent='FBM';
  q.querySelector('input').addEventListener('input',e=>{window.lastQuantity=e.target.value;});
  initSelections();out.textContent='DOM 已加载，可以运行本地验证。';
}
document.querySelector('#fill').onclick=async()=>{try{
  const result=await DXMAdapter.commands.fill({record,modelName:'/01'});
  assert(app.querySelector('input[placeholder="必填项，Prodcut ID"]').value==='780715899310','UPC错误');
  assert(app.querySelector('[id="form_item_item_dimensions.0.length.value"]').value==='0','0值被跳过');
  assert(app.querySelector('[id="form_item_color.0.value"]').value==='Gold','颜色错误');
  assert(window.lastQuantity==='','数量未先清空');assert(!app.querySelector('input[placeholder="请输入产品数量"]'),'FBA后数量控件未移除');
  out.textContent='PASS：UPC、SKU、0值尺寸、颜色、包装单位、数量先清空再FBA和固定属性。\n'+result.written.join('、');
}catch(e){out.textContent='FAIL：'+e.message;}};
document.querySelector('#mismatch').onclick=async()=>{try{await DXMAdapter.commands.fill({record:{...record,source:'https://amazon.com/dp/B000000000'},modelName:'/01'});out.textContent='FAIL：未阻止错误来源';}catch(e){out.textContent=e.message.includes('来源链接不匹配')?'PASS：来源不匹配，已阻止写入。':'FAIL：'+e.message;}};
document.querySelector('#crawl').onclick=async()=>{app.innerHTML='<div class="vxe-table--main-wrapper"><table><tbody>'+await(await fetch('/docs/evidence/collected-row.html')).text()+'</tbody></table></div>';const rows=DXMAdapter.rows();out.textContent=rows.length===1&&rows[0].id==='184527809328870833'?'PASS：固定列重复行已去重，采集ID及来源标题正确。':'FAIL：'+JSON.stringify(rows);};
document.querySelector('#online').onclick=async()=>{app.innerHTML='<div class="vxe-table--main-wrapper"><table><tbody>'+await(await fetch('/docs/evidence/online-product.html')).text()+'</tbody></table></div>';const rows=DXMAdapter.rows();out.textContent=rows.length===1&&rows[0].id==='184807703383437685'&&rows[0].fba?'PASS：在线产品ID、原来源链接和FBA标识正确。':'FAIL：'+JSON.stringify(rows);};
setup().catch(e=>out.textContent='FAIL：'+e.message);
