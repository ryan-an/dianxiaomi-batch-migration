const fs=require('node:fs'),X=require('../extension/vendor/xlsx.full.min.js'),C=require('../extension/core.js');
const r=C.parseWorkbook(X.read(fs.readFileSync('迁移数据.xls')),X,{mergeSplit:true}).rows[0];r.title='10 PCS Gold S Hooks, Brass S Hooks for Hanging, 3.54 Inch';
fs.writeFileSync('tests/fixture-data.json',JSON.stringify(r));
const items=JSON.parse(fs.readFileSync('docs/evidence/editor-required-items.json','utf8'));
fs.writeFileSync('docs/evidence/editor-form.html','<!-- Verified required fields, captured separately to avoid truncation. -->\n<form>'+items.map(x=>x.html).join('\n')+'</form>');
const html=fs.readFileSync('extension/popup.html','utf8').replace('href="popup.css"','href="/extension/popup.css"').replace(/src="/g,'src="/extension/').replace('<script src="/extension/vendor','<script src="/tests/mock-chrome.js"></script><script src="/extension/vendor');
fs.writeFileSync('tests/popup-preview.html',html.replace(/src="([^"?]+\.js)"/g,(_,url)=>`src="${url}?v=${Math.trunc(fs.statSync('.'+url).mtimeMs)}"`));
