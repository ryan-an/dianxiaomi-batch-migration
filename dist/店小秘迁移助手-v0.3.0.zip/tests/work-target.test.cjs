const test=require('node:test'),assert=require('node:assert/strict'),T=require('../extension/work-target.js');
const tab=(id,path='amazon/pageList/draft',extra={})=>({id,url:'https://www.dianxiaomi.com/web/'+path,...extra});
test('自动匹配当前窗口的店小秘页面，排除扩展页和伪造域名',()=>{
  const tabs=[tab(1),tab(2,'productCrawl/dataAcquisition',{lastAccessed:100}),{id:3,url:'chrome-extension://local/popup.html'},{id:4,url:'https://www.dianxiaomi.com.example.org/web/amazon/'}];
  assert.equal(T.chooseTab(tabs,[tab(1)]).id,1);assert.equal(T.chooseTab(tabs,[tabs[2]]).id,2);assert.equal(T.allowedTab(tabs[3]),false);
});
test('其他窗口最近使用的店小秘页面可自动接管',async()=>{
  const tabs=[tab(1,'amazon/pageList/draft',{lastAccessed:9}),tab(2,'amazon/pageList/offline',{lastAccessed:20})],api={tabs:{query:async filter=>filter.url?tabs:[]}};
  assert.equal((await T.resolve(api)).id,2);
});
test('没有店小秘页面时给出可直接处理的提示',async()=>{
  await assert.rejects(T.resolve({tabs:{query:async()=>[]}}),/打开并登录店小秘/);
});
