const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
function boot({failSave=false,noTabs=false,rejectRun=false,previous=null}={}){
  const data={dxmJob:previous},tasks=[],sent=[],badges=[],created=[];let listener,action;
  const context=vm.createContext({URL,structuredClone,console,crypto:{randomUUID:()=> 'local-run'},setTimeout:fn=>tasks.push(fn)});
  context.chrome={action:{onClicked:{addListener:fn=>action=fn},setBadgeText:async v=>badges.push(v),setTitle:async()=>{}},storage:{local:{get:async key=>({[key]:structuredClone(data[key])}),set:async value=>{if(failSave)throw new Error('存储空间不足');Object.assign(data,structuredClone(value));}}},runtime:{onMessage:{addListener:fn=>listener=fn}},tabs:{query:async filter=>noTabs?[]:filter.url?[{id:101,url:'https://www.dianxiaomi.com/web/amazon/pageList/draft'}]:[{id:101,url:'https://www.dianxiaomi.com/web/amazon/pageList/draft'}],get:async id=>({id,url:'https://www.dianxiaomi.com/web/amazon/pageList/draft'}),update:async()=>{},create:async v=>created.push(v),sendMessage:async(id,m)=>{sent.push({id,...m});return {ok:true};},onRemoved:{addListener:()=>{}}}};
  context.importScripts=(...names)=>{for(const name of names){if(name==='workflow.js'){context.DXMWorkflow=class{async run(){if(rejectRun)throw new Error('存储失败');}};}else vm.runInContext(fs.readFileSync(path.join('extension',name),'utf8'),context,{filename:name});}};
  vm.runInContext(fs.readFileSync('extension/background.js','utf8'),context,{filename:'background.js'});
  return {data,tasks,sent,badges,created,click:tab=>action(tab),send:(m,tab)=>new Promise(resolve=>listener(m,tab?{tab}:{},r=>resolve(structuredClone(r))))};
}
const rows=()=>[1,2].map(i=>({source:`https://www.amazon.com/dp/B0TEST000${i}`,shop:'万万欣UK',site:'英国',targetShop:'旧的错误映射',data:{},error:'',status:'待执行'}));
test('点击工具栏打开网页内面板，不依赖独立窗口 API',async()=>{
  const manifest=JSON.parse(fs.readFileSync('extension/manifest.json'));assert.equal(manifest.action.default_popup,undefined);
  const b=boot();assert.equal((await b.send({kind:'DXM_STATUS'})).ok,true);
  await b.click({id:202,url:'https://www.dianxiaomi.com/web/amazon/pageList/draft'});assert.deepEqual(b.sent,[{id:202,kind:'DXM_PANEL_OPEN'}]);assert.equal(b.badges[0].text,'');
});
test('没有工作页面时工具栏打开采集页面，页面自身显示面板',async()=>{
  const b=boot({noTabs:true});await b.click({id:5,url:'https://example.com'});assert.equal(b.created.length,1);assert.equal(b.created[0].url,'https://www.dianxiaomi.com/web/productCrawl/dataAcquisition');assert.equal(b.sent.length,0);
});
test('点击网页面板开始时绑定这个标签页',async()=>{
  const b=boot();await b.send({kind:'DXM_START',rows:rows()},{id:202,url:'https://www.dianxiaomi.com/web/amazon/pageList/offline'});assert.equal((await b.send({kind:'DXM_STATUS'})).job.tabId,202);assert.equal((await b.send({kind:'DXM_STATUS'},{id:202})).owner,true);assert.equal((await b.send({kind:'DXM_STATUS'},{id:101})).owner,false);
});
test('整表自动执行，旧范围和旧店铺设置不能影响本轮',async()=>{
  const b=boot(),r=await b.send({kind:'DXM_START',rows:rows(),options:{startIndex:2,limit:1},tabId:999});assert.equal(r.ok,true);
  const job=(await b.send({kind:'DXM_STATUS'})).job;assert.equal(job.tabId,101);assert.equal(job.options.startIndex,1);assert.equal(job.options.limit,2);assert.equal(job.options.modelNameFromNumber,true);assert.ok(job.rows.every(r=>r.status==='待执行'&&r.targetShop==='万万欣DE'));assert.equal(b.tasks.length,1);
  assert.match((await b.send({kind:'DXM_START',rows:rows()})).error,/已有批次/);
});
test('缺少工作页面时返回错误，保留上次结果，不启动工作流',async()=>{
  const previous={state:'done',rows:[]},b=boot({noTabs:true,previous});assert.match((await b.send({kind:'DXM_START',rows:rows()})).error,/打开并登录/);assert.deepEqual((await b.send({kind:'DXM_STATUS'})).job,previous);assert.equal(b.tasks.length,0);
});
test('开始时保存失败不会留下假运行状态或锁住页面',async()=>{
  const b=boot({failSave:true});assert.match((await b.send({kind:'DXM_START',rows:rows()})).error,/存储空间/);assert.equal((await b.send({kind:'DXM_STATUS'})).job,null);assert.equal(b.tasks.length,0);
});
test('后台意外拒绝会返回待核对，避免未处理的 Promise 错误',async()=>{
  const b=boot({rejectRun:true});await b.send({kind:'DXM_START',rows:rows()});await b.tasks[0]();const job=(await b.send({kind:'DXM_STATUS'})).job;assert.equal(job.state,'review');assert.ok(job.rows.every(r=>r.status==='待人工核对'));assert.match(job.error,/存储失败/);
});
