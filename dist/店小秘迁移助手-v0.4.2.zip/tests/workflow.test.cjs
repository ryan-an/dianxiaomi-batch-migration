const {test}=require('node:test'),assert=require('node:assert/strict');global.DXMCore=require('../extension/core.js');const Workflow=require('../extension/workflow.js');
const product=(i=1)=>({index:i-1,source:`https://www.amazon.com/dp/B0TEST000${i}`,shop:'万万欣UK',targetShop:'万万欣DE',site:'英国',data:{'Model Number':'/01'},title:'',status:'待执行',history:[],error:''});
function scenario(records,options={}){
  const job={rows:records,logs:[],state:'running',options:{modelNameFromNumber:true}};
  let path='',tab='',claimed=false,moved=false,retried=false,editorId='',movePolls=0;const sent=[],published=new Set();
  const crawl=r=>({id:`c${r.index}`,rowId:`row${r.index}`,source:r.source,title:`Title ${r.index}`,text:`Title ${r.index}`});
  const listing=r=>({id:`p${r.index}`,source:r.source,title:`Title ${r.index}`,text:`Title ${r.index}「万万欣DE」英国`,editUrl:`https://www.dianxiaomi.com/web/amazon/edit?id=p${r.index}`,links:[]});
  const io={save:async()=>{},sleep:async()=>{},open:async u=>{assert.ok(!job.pendingMove,'结果确认前不能跳转');sent.push({a:'open',url:u});path=u;editorId=new URL(u).searchParams.get('id');},call:async(a,args={},risky=false)=>{
    sent.push({a,args,risky});
    if(a==='acquisitionTab'){tab=args.name;return {};}
    if(a==='snapshot'){
      let rows=[];
      if(path.includes('productCrawl')){
        if(tab==='全部')rows=options.existing?[crawl(records[0])]:[];
        if(tab==='采集失败'&&options.retry&&!retried)rows=[crawl(records[0])];
        if(tab==='未认领'&&!claimed)rows=records.map(crawl);
      }else if(path.endsWith('/draft'))rows=claimed&&!moved?records.map(listing):[];
      else if(path.endsWith('/offline'))rows=records.map(listing);
      else if(path.endsWith('/online'))rows=records.filter(r=>published.has(`p${r.index}`)).map(listing);
      if(options.ambiguous&&path.endsWith('/draft'))rows.push({...listing(records[0]),id:'duplicate'});
      return {rows,hasNext:false,signature:JSON.stringify(rows.map(r=>r.id))};
    }
    if(a==='claim'){assert.ok(args.ids.every(x=>x.startsWith('c')));assert.equal(args.shop,'万万欣DE');claimed=true;}
    if(a==='move'){assert.ok(args.ids.every(x=>x.startsWith('p')));return {submitted:true};}
    if(a==='moveProgress'){
      movePolls++;
      if(options.moveDisconnected)throw new Error('进度连接中断');
      if(movePolls<(options.movePolls||1))return {done:false,text:`正在移入 ${movePolls}`};
      moved=true;return {done:true,success:records.length-(options.moveFailed||0),failed:options.moveFailed||0,text:'执行结果'};
    }
    if(a==='retry')retried=true;
    if(a==='progress')return {done:true,text:'已完成'};
    if(a==='fill'){assert.equal(args.modelName,'/01');if(options.fieldError){const e=new Error('填写【配送渠道】失败：选项未展开');e.field='配送渠道';e.completedFields=['库存数量清空'];throw e;}return {written:['UPC','FBA']};}
    if(a==='publish'){if(options.uncertain){const e=new Error('连接断开');e.uncertain=true;throw e;}published.add(editorId);}
    if(a==='publishStatus')return options.validation?{done:true,failed:true,text:'请输入型号名称'}:{done:true,submitted:true};
    return {};
  }};
  return {job,sent,run:()=>new Workflow(job,io).run()};
}
test('分组批量认领和移动，只提交本批次ID，最终核实在线状态',async()=>{const s=scenario([product(1),product(2)]);await s.run();assert.equal(s.job.state,'done');assert.ok(s.job.rows.every(r=>r.status==='已上线'));assert.equal(s.sent.filter(x=>x.a==='collect').length,1);assert.equal(s.sent.find(x=>x.a==='claim').args.ids.length,2);});
test('历史来源直接跳过，不消耗手动做过的产品',async()=>{const s=scenario([product()],{existing:true});await s.run();assert.equal(s.job.rows[0].status,'已跳过');assert.equal(s.sent.filter(x=>x.risky).length,0);});
test('采集失败只重试一次',async()=>{const s=scenario([product()],{retry:true});await s.run();assert.equal(s.sent.filter(x=>x.a==='retry').length,1);assert.equal(s.job.rows[0].retryCount,1);});
test('同链接同店铺的重复产品使流程失败，不执行移入或发布',async()=>{const s=scenario([product()],{ambiguous:true});await s.run();assert.equal(s.job.rows[0].status,'失败');assert.equal(s.sent.filter(x=>['move','publish'].includes(x.a)).length,0);});
test('表单校验错误不算发布成功',async()=>{const s=scenario([product()],{validation:true});await s.run();assert.equal(s.job.rows[0].status,'失败');assert.match(s.job.rows[0].error,/型号名称/);});
test('提交结果不确定时停止，不继续下一个产品或自动重复提交',async()=>{const s=scenario([product(1),product(2)],{uncertain:true});await s.run();assert.equal(s.job.state,'review');assert.equal(s.sent.filter(x=>x.a==='publish').length,1);assert.ok(s.job.rows.every(r=>r.status==='待人工核对'));});
test('翻页批量处理排除历史产品，处理后重新从首页定位剩余ID',async()=>{
  const job={rows:[],logs:[],state:'running'},members=[{collectorId:'c1',history:[]},{collectorId:'c2',history:[]}];let page=0;const done=new Set(),batches=[];
  const io={save:async()=>{},call:async(a,arg)=>{
    if(a==='firstPage'){page=0;return {};}
    if(a==='nextPage'){page++;return {};}
    if(a==='snapshot')return {rows:page===0?[{id:'foreign'}]:page===1&&!done.has('c1')?[{id:'c1'},{id:'foreign2'}]:page===2&&!done.has('c2')?[{id:'c2'}]:[],hasNext:page<2,signature:String(page)};
    if(a==='claim'){batches.push(arg.ids);arg.ids.forEach(i=>done.add(i));return {};}
    if(a==='progress')return {done:true,text:'完成'};
    return {};
  }};
  await new Workflow(job,io).pageBatches(members,'collectorId','claim');assert.deepEqual(batches,[['c1'],['c2']]);
});
test('分页不前进时停止，避免漏行或无限循环',async()=>{
  const job={logs:[],rows:[]},io={save:async()=>{},call:async a=>a==='snapshot'?{rows:[],hasNext:true,signature:'same'}:{}};
  await assert.rejects(()=>new Workflow(job,io).scan(),/分页没有前进/);
});
test('移动超过旧版等待时长也持续轮询，最终结果之前不关闭、翻页或跳转',async()=>{
  const s=scenario([product()],{movePolls:50});await s.run();
  assert.equal(s.job.state,'done');assert.equal(s.sent.filter(x=>x.a==='move').length,1);
  const start=s.sent.findIndex(x=>x.a==='move'),close=s.sent.findIndex(x=>x.a==='closeMoveProgress');
  assert.equal(s.sent.slice(start+1,close).length,50);assert.ok(s.sent.slice(start+1,close).every(x=>x.a==='moveProgress'));
  assert.equal(s.sent[close+1].a,'open');assert.match(s.sent[close+1].url,/\/offline$/);assert.equal(s.job.pendingMove,null);
});
test('移动进度断开时保留页面和待核对状态，不发布、不自动再次提交',async()=>{
  const s=scenario([product(1),product(2)],{moveDisconnected:true});await s.run();
  assert.equal(s.job.state,'review');assert.ok(s.job.pendingMove);assert.ok(s.job.rows.every(r=>r.status==='待人工核对'));
  const after=s.sent.slice(s.sent.findIndex(x=>x.a==='move')+1);assert.deepEqual(after.map(x=>x.a),['moveProgress']);
});
test('移动最终结果有失败时保留弹窗，不把部分成功当全成功',async()=>{
  const s=scenario([product(1),product(2)],{moveFailed:1});await s.run();
  assert.equal(s.job.state,'review');assert.match(s.job.error,/成功 1，失败 1/);assert.ok(s.job.pendingMove);
  assert.equal(s.sent.filter(x=>x.a==='closeMoveProgress'||x.a==='publish').length,0);
});
test('移动15分钟未结束时停止轮询，不关闭弹窗或执行任何跳转',async()=>{
  const job={logs:[],rows:[],state:'running'},members=[{productId:'p1',history:[]}],sent=[];let now=0;
  const realNow=Date.now;Date.now=()=>now;
  try{
    const io={save:async()=>{},sleep:async ms=>{now+=ms;},call:async a=>{sent.push(a);if(a==='snapshot')return {rows:[{id:'p1'}],hasNext:false};if(a==='moveProgress')return {done:false,text:'进行中'};return {};}};
    await assert.rejects(()=>new Workflow(job,io).pageBatches(members,'productId','move'),e=>e.uncertain&&/15分钟/.test(e.message));
    assert.ok(job.pendingMove);assert.equal(sent.filter(x=>x==='move').length,1);assert.ok(!sent.includes('closeMoveProgress'));
  }finally{Date.now=realNow;}
});
test('填写失败保留具体字段与已经完成的字段，不提交发布',async()=>{
  const s=scenario([product()],{fieldError:true});await s.run();const row=s.job.rows[0];
  assert.equal(row.failedField,'配送渠道');assert.deepEqual(row.completedFields,['库存数量清空']);assert.match(row.error,/配送渠道/);assert.equal(s.sent.filter(m=>m.a==='publish').length,0);
});
