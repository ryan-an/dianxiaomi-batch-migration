importScripts('core.js','workflow.js','work-target.js');
let job=null,busy=false,loadPromise=null;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
chrome.action.onClicked.addListener(async tab=>{
  try{
    let target=DXMTarget.allowedTab(tab)?tab:null;
    if(!target){try{target=await DXMTarget.resolve(chrome);}catch{await chrome.tabs.create({url:'https://www.dianxiaomi.com/web/productCrawl/dataAcquisition',active:true});return;}}
    await chrome.tabs.update(target.id,{active:true});
    const result=await chrome.tabs.sendMessage(target.id,{kind:'DXM_PANEL_OPEN'});
    if(!result?.ok)throw new Error('请刷新店小秘页面，再点击插件图标。');
    await chrome.action.setBadgeText({text:''});
    await chrome.action.setTitle({title:'显示网页内迁移面板'});
  }catch{
    await chrome.action.setBadgeText({text:'刷新'});
    await chrome.action.setTitle({title:'请刷新店小秘页面，再点击插件图标显示面板'});
  }
});
async function save(){if(job)await chrome.storage.local.set({dxmJob:job});}
async function load(){
  if(loadPromise)return loadPromise;
  loadPromise=(async()=>{job=(await chrome.storage.local.get('dxmJob')).dxmJob||null;
  if(job?.state==='running'){
    job.state='review';job.error='浏览器或后台曾中断，请核对页面。为避免重复发布，不自动重跑。';
    for(const r of job.rows)if(!['未执行','数据错误','失败','已跳过','已上线','已提交待确认'].includes(r.status)){r.status='待人工核对';r.error=job.error;}
    await save();
  }})();return loadPromise;
}
function allowed(url){const u=new URL(url);return u.origin==='https://www.dianxiaomi.com'&&/^\/web\/(amazon\/|productCrawl\/)/.test(u.pathname);}
async function raw(action,args={}){
  if(job.stop&&action!=='stop')throw new Error('用户已停止');
  const result=await chrome.tabs.sendMessage(job.tabId,{kind:'DXM_ACTION',action,args,runId:job.id});
  if(!result?.ok){const e=new Error(result?.error||'页面没有返回执行结果');e.field=result?.field;e.completedFields=result?.completedFields;throw e;}return result.data;
}
const io={save,sleep:pause,
  async call(action,args={},risky=false){
    if(job.stop)throw new Error('用户已停止');
    if(risky){job.intent={action,time:new Date().toISOString()};await save();}
    try{const data=await raw(action,args);job.intent=null;await save();return data;}
    catch(e){if(risky)e.uncertain=true;throw e;}
  },
  async open(url,record){
    if(!allowed(url))throw new Error('不允许跳转到店小秘工作流之外的地址');
    if(job.stop)throw new Error('用户已停止');
    if(job.pendingMove){const e=new Error('移入待发布结果尚未确认，已阻止刷新或跳转');e.uncertain=true;throw e;}
    await chrome.tabs.update(job.tabId,{url});
    const end=Date.now()+45000;let error;
    while(Date.now()<end){
      if(job.stop)throw new Error('用户已停止');
      try{
        const tab=await chrome.tabs.get(job.tabId);
        if(tab.status==='complete'&&DXMTarget.samePage(tab.url,url)){
          const ready=await raw('ready',{expectedUrl:url,record});
          if(DXMTarget.samePage(ready.url,url)&&(!record||DXMCore.sourceKey(ready.source)===DXMCore.sourceKey(record.source)))return ready;
          error=new Error('页面仍在切换，尚未加载到目标产品ID及来源链接');
        }
      }catch(e){error=e;}
      await pause(500);
    }
    throw new Error(`页面未准备好：${error?.message||url}`);
  }
};
chrome.runtime.onMessage.addListener((m,s,reply)=>{
  (async()=>{
    await load();
    if(m.kind==='DXM_STATUS')return {ok:true,job,owner:s.tab?.id===job?.tabId};
    if(m.kind==='DXM_FIELD_PROGRESS'){
      if(!job||job.state!=='running'||job.stop||s.tab?.id!==job.tabId||m.runId!==job.id)throw new Error('批次已失效，禁止继续填写');
      const r=job.rows.find(r=>r.productId===m.productId&&DXMCore.sourceKey(r.source)===DXMCore.sourceKey(m.source));
      if(!r||typeof m.field!=='string'||!m.field||m.field.length>100)throw new Error('字段日志与当前产品不匹配');
      const entry={time:new Date().toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false}),message:`正在填写：${m.field}`};
      job.logs.push(entry);if(job.logs.length>1000)job.logs.shift();r.history.push(entry);r.currentField=m.field;await save();return {ok:true};
    }
    if(m.kind==='DXM_STOP'){
      if(job&&busy){job.stop=true;await save();try{await chrome.tabs.sendMessage(job.tabId,{kind:'DXM_ACTION',action:'stop'});}catch{}}
      return {ok:true};
    }
    if(m.kind==='DXM_START'){
      if(busy)throw new Error('已有批次正在执行');
      busy=true;
      try {
      if(!Array.isArray(m.rows)||!m.rows.length)throw new Error('没有有效数据');
      const tab=await DXMTarget.resolve(chrome,s.tab);
      const options={startIndex:1,limit:m.rows.length,modelNameFromNumber:true};
      const rows=structuredClone(m.rows);
      for(let i=0;i<rows.length;i++){
        const r=rows[i];r.history=[];
        if(!r.error){DXMCore.sourceKey(r.source);r.targetShop=DXMCore.alias[`${r.shop}|${r.site}`]||r.shop;r.status='待执行';}
      }
      if(!rows.some(r=>!r.error))throw new Error('表格中没有可执行的产品，请检查原表数据');
      const nextJob={id:crypto.randomUUID(),state:'running',rows,logs:[],options,tabId:tab.id,startedAt:new Date().toISOString(),step:'准备',stop:false,intent:null};
      await chrome.storage.local.set({dxmJob:nextJob});job=nextJob;
      setTimeout(()=>new DXMWorkflow(job,io).run().catch(async e=>{
        job.state='review';job.stop=true;job.error=`后台执行中断，请核对当前产品：${e.message}`;
        for(const r of job.rows)if(!['数据错误','失败','已跳过','已上线','已提交待确认','发布失败'].includes(r.status)){r.status='待人工核对';r.error=job.error;}
        try{await save();}catch{}
      }).finally(()=>{busy=false;}),0);
      return {ok:true};
      }catch(e){busy=false;throw e;}
    }
    throw new Error('未知请求');
  })().then(reply,e=>reply({ok:false,error:e.message}));return true;
});
chrome.tabs.onRemoved.addListener(async tabId=>{await load();if(job?.tabId===tabId&&busy){job.stop=true;job.error='执行标签页已关闭';await save();}});
