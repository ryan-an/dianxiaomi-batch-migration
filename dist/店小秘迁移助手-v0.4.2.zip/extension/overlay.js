(function(){
  'use strict';
  if(globalThis.DXMPanel||document.getElementById('dxm-migration-panel'))return;
  const host=document.createElement('div');host.id='dxm-migration-panel';
  host.style.cssText='all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
  const root=host.attachShadow({mode:'open'});
  root.innerHTML=`<style>${DXMPanelView.css}
    #surface{position:fixed;right:20px;top:112px;width:480px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 24px);overflow:auto;overscroll-behavior:contain;pointer-events:auto;background:#fff;border:1px solid #dce5f1;border-radius:15px;box-shadow:0 12px 48px #22395c33}
    #surface.dragging>main>header{cursor:grabbing}
    #shade{position:fixed;inset:0;background:#213d640d;pointer-events:auto}
    #launcher{position:fixed;pointer-events:auto;background:#245bd6;color:white;border-color:#245bd6;padding:9px 15px;border-radius:10px;box-shadow:0 4px 20px #22395c33;font-size:13px}
  </style><div id="shade" hidden></div><aside id="surface" aria-label="店小秘迁移浮动面板">${DXMPanelView.html}</aside><button id="launcher" type="button" hidden>迁移助手</button>`;
  document.documentElement.append(host);
  const surface=root.getElementById('surface'),launcher=root.getElementById('launcher'),header=root.querySelector('main>header');
  let locked=false,collapsed=false,position=null,drag=null,moved=false,explicitOpen=false;
  const store=async value=>{try{await chrome.storage.local.set(value);}catch{}};
  function place(){
    const target=collapsed?launcher:surface,rect=target.getBoundingClientRect();
    position=DXMPanelLayout.fit(position,{width:innerWidth,height:innerHeight},{width:rect.width,height:rect.height});
    for(const el of [surface,launcher]){el.style.right='auto';el.style.left=`${position.left}px`;el.style.top=`${position.top}px`;}
  }
  function setCollapsed(value,persist=true){
    collapsed=value;surface.hidden=value;launcher.hidden=!value;place();
    if(persist)store({dxmPanelCollapsed:value});
  }
  function show(){explicitOpen=true;setCollapsed(false);root.dispatchEvent(new CustomEvent('dxm-panel-open'));}
  launcher.onclick=show;
  function guard(event){if(locked&&event.isTrusted&&!event.composedPath().includes(host)){event.preventDefault();event.stopImmediatePropagation();}}
  for(const type of ['click','dblclick','pointerdown','pointerup','mousedown','mouseup','touchstart','keydown','wheel','contextmenu'])document.addEventListener(type,guard,{capture:true,passive:false});
  header.addEventListener('pointerdown',event=>{
    if(event.button!==0||event.target.closest('button'))return;
    const rect=surface.getBoundingClientRect();drag={id:event.pointerId,x:event.clientX-rect.left,y:event.clientY-rect.top};
    header.setPointerCapture(event.pointerId);surface.classList.add('dragging');event.preventDefault();
  });
  header.addEventListener('pointermove',event=>{
    if(!drag||drag.id!==event.pointerId)return;
    moved=true;position={left:event.clientX-drag.x,top:event.clientY-drag.y};place();event.preventDefault();
  });
  function finish(event){
    if(!drag||event.pointerId!==drag.id)return;const id=drag.id;drag=null;surface.classList.remove('dragging');
    if(header.hasPointerCapture(id))header.releasePointerCapture(id);
    if(moved)store({dxmPanelPosition:position});
  }
  for(const type of ['pointerup','pointercancel','lostpointercapture'])header.addEventListener(type,finish);
  addEventListener('resize',()=>requestAnimationFrame(place));
  globalThis.DXMPanel={root,show,collapse:()=>setCollapsed(true),update(value){
    locked=!!value.locked;root.getElementById('shade').hidden=!locked;
    launcher.textContent=value.summary?.busy?'迁移执行中 · 点击展开':'迁移助手';
    requestAnimationFrame(place);
  }};
  chrome.runtime.onMessage?.addListener((message,sender,reply)=>{
    if(message.kind!=='DXM_PANEL_OPEN')return;show();reply({ok:true});
  });
  place();
  chrome.storage.local.get(['dxmPanelPosition','dxmPanelCollapsed']).then(saved=>{
    if(!moved)position=saved.dxmPanelPosition||position;
    setCollapsed(!explicitOpen&&saved.dxmPanelCollapsed===true,false);
  }).catch(()=>{});
})();
